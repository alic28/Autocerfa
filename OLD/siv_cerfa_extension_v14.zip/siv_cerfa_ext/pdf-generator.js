/**
 * SIV → CERFA — pdf-generator.js
 *
 * Remplit un PDF CERFA dans le navigateur via pdf-lib (déjà chargé).
 * - Charge le template JPEG en arrière-plan d'une page A4
 * - Dessine le texte aux coordonnées calibrées (image px → PDF pt)
 * - Retourne un Blob PDF prêt à ouvrir / télécharger
 *
 * Convention coords.json :
 *   x, y       = position du COIN HAUT-GAUCHE du texte, en pixels image
 *   w          = largeur disponible pour le texte (informatif, pas utilisé pour rendre)
 *   fs         = font size en points PDF
 *   image_w/h  = dimensions de référence de l'image utilisée pour calibrer
 *
 * Conversion :
 *   sx = pdf_width  / image_width   (≈ 0.48 si A4 + 1240px)
 *   sy = pdf_height / image_height
 *   pdf_x       = x * sx
 *   pdf_y_top   = pdf_height - y * sy
 *   baseline_y  = pdf_y_top - fs * 0.85   (descend de l'ascent pour que top du texte = pdf_y_top)
 */

(function (global) {
  "use strict";

  // ── Format A4 portrait standard ────────────────────────────────────────
  const A4_WIDTH_PT  = 595.28;
  const A4_HEIGHT_PT = 841.89;

  /**
   * Génère un PDF CERFA rempli.
   * @param {string} formId          - "13750" ou "13757"
   * @param {object} payload         - dictionnaire { key: value } (clés = field.key dans coords.json)
   * @param {object} coords          - coords.json complet
   * @param {string} templateUrl     - URL du JPG template (chrome.runtime.getURL)
   * @returns {Promise<Blob>}        - blob PDF
   */
  async function fillCerfa(formId, payload, coords, templateUrl) {
    const { PDFDocument, StandardFonts, rgb } = global.PDFLib;

    const formCoords = coords[formId];
    if (!formCoords) throw new Error(`Form ${formId} introuvable dans coords.json`);

    // ── Charger le JPG template ─────────────────────────────────────────
    const jpgBytes = await fetch(templateUrl).then(r => {
      if (!r.ok) throw new Error(`Template ${templateUrl} introuvable (${r.status})`);
      return r.arrayBuffer();
    });

    // ── Créer un PDF A4 vide ────────────────────────────────────────────
    const pdfDoc = await PDFDocument.create();
    const font   = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const page   = pdfDoc.addPage([A4_WIDTH_PT, A4_HEIGHT_PT]);

    // ── Dessiner le JPG en fond de page ─────────────────────────────────
    const jpgImage = await pdfDoc.embedJpg(jpgBytes);
    page.drawImage(jpgImage, {
      x: 0, y: 0,
      width:  A4_WIDTH_PT,
      height: A4_HEIGHT_PT
    });

    // ── Calculer les facteurs de mise à l'échelle ───────────────────────
    const sx = A4_WIDTH_PT  / formCoords.image_width;
    const sy = A4_HEIGHT_PT / formCoords.image_height;

    // ── Dessiner chaque champ ───────────────────────────────────────────
    for (const f of formCoords.fields) {
      let value = payload[f.key];
      if (value === undefined || value === null) continue;
      value = String(value).trim();
      if (!value) continue;

      const fs   = f.fs || 9;
      const xPt  = f.x * sx;
      const yTop = A4_HEIGHT_PT - f.y * sy;
      const yBl  = yTop - fs * 0.85;       // baseline ≈ top - ascent

      // Tronquer le texte s'il dépasse la largeur disponible
      const maxWidth = (f.w || 999) * sx;
      let displayText = value;
      let textWidth   = font.widthOfTextAtSize(displayText, fs);

      if (textWidth > maxWidth && displayText.length > 3) {
        // Réduire le font_size avant de tronquer (jusqu'à fs-2)
        let fsAuto = fs;
        while (textWidth > maxWidth && fsAuto > fs - 3 && fsAuto > 6) {
          fsAuto -= 0.5;
          textWidth = font.widthOfTextAtSize(displayText, fsAuto);
        }
        if (textWidth > maxWidth) {
          // Sinon tronquer
          while (displayText.length > 1 && font.widthOfTextAtSize(displayText + "…", fsAuto) > maxWidth) {
            displayText = displayText.slice(0, -1);
          }
          displayText += "…";
        }
        page.drawText(displayText, {
          x: xPt, y: yBl, size: fsAuto, font, color: rgb(0, 0, 0)
        });
      } else {
        page.drawText(displayText, {
          x: xPt, y: yBl, size: fs, font, color: rgb(0, 0, 0)
        });
      }
    }

    // ── Export ──────────────────────────────────────────────────────────
    const pdfBytes = await pdfDoc.save();
    return new Blob([pdfBytes], { type: "application/pdf" });
  }

  // Export global
  global.SivCerfaPdf = { fillCerfa };

})(window);
