/**
 * SIV → CERFA — Content Script v1.2
 * Détection par URLs exactes pro-siv.interieur.gouv.fr
 *
 * URLs connues :
 *   ivo_cht_recherche_init  → Écran 1 : saisie véhicule + ancien proprio
 *   sp_saisiepers           → Écran saisie du nouveau titulaire (formulaire)
 *   sp_action               → Écran titulaire / co-titulaire (tableau récap partiel)
 *   ivo_cht_toVal           → Écran récapitulatif complet  ⭐ bouton CERFA ici
 */
(function () {
  "use strict";

  // ─── Détection écran par URL (fiable à 100%) ───────────────────────────────

  const ACTION = window.location.pathname.split("/do/").pop() || "";

  const SCREENS = {
    VEHICULE:   "ivo_cht_recherche_init",   // Écrans 1+2
    TITULAIRE:  "sp_saisiepers",            // Saisie nouveau titulaire
    COTIT:      "sp_action",               // Tableau titulaire / co-titulaire
    RECAP:      "ivo_cht_toVal",            // Récapitulatif complet ⭐
  };

  function getScreen() {
    if (ACTION === SCREENS.VEHICULE)  return "vehicule";
    if (ACTION === SCREENS.TITULAIRE) return "titulaire";
    if (ACTION === SCREENS.COTIT)     return "cotitulaire";
    if (ACTION === SCREENS.RECAP)     return "recap";
    return "autre";
  }

  const SCREEN = getScreen();

  // ─── Numéro de dossier ─────────────────────────────────────────────────────

  function getDossier() {
    // Format SIV : "Dossier N° : GP-910-RT"  ou affiché dans un <h2>/<span>
    const m = document.body.innerText.match(
      /Dossier\s+N[°o\.]\s*[:\-]?\s*([A-Z]{2}-\d{3}-[A-Z]{2})/i
    );
    return m ? m[1].trim() : "";
  }

  // ─── Helpers DOM ───────────────────────────────────────────────────────────

  /** Lit un input associé à un libellé texte (parcourt td/th/label/div) */
  function byLabel(txt) {
    for (const el of document.querySelectorAll("td, th, label, div, span")) {
      if (!el.textContent.trim().toLowerCase().includes(txt.toLowerCase())) continue;
      // 1. Input dans l'élément lui-même
      const self = el.querySelector("input:not([type=hidden]), select");
      if (self?.value) return self.value.trim();
      // 2. Input dans la cellule suivante
      const next = el.nextElementSibling;
      if (next) {
        const ni = next.querySelector("input:not([type=hidden]), select");
        if (ni?.value) return ni.value.trim();
        const nt = next.textContent.trim();
        if (nt && nt.length < 200 && nt !== txt) return nt;
      }
      // 3. Input dans la ligne de tableau parente
      const row = el.closest("tr, fieldset, div.champ");
      if (row) {
        const ri = row.querySelector("input:not([type=hidden]), select");
        if (ri?.value) return ri.value.trim();
      }
    }
    return "";
  }

  /** Lit un input par fragment de son attribut name */
  function byName(...frags) {
    for (const f of frags) {
      const el = document.querySelector(
        `input[name*="${f}"]:not([type=hidden]), select[name*="${f}"]`
      );
      if (el?.value) return el.value.trim();
    }
    return "";
  }

  /**
   * Lit une valeur dans le tableau récapitulatif par son code champ.
   * Ex : readRecap("D.1") → valeur de l'input après la cellule "D.1"
   */
  function readRecap(code) {
    for (const cell of document.querySelectorAll("td, th")) {
      if (cell.textContent.trim() !== code) continue;
      const inp = cell.querySelector("input");
      if (inp) return inp.value.trim();
      const next = cell.nextElementSibling;
      if (!next) continue;
      const ni = next.querySelector("input");
      if (ni) return ni.value.trim();
      const val = next.textContent.trim();
      if (val && val !== code) return val;
    }
    return "";
  }

  /** Sexe depuis les radio buttons de la page */
  function readSexe() {
    for (const r of document.querySelectorAll('input[type="radio"]:checked')) {
      const lbl = document.querySelector(`label[for="${r.id}"]`);
      const t = (lbl?.textContent || r.value || "").toLowerCase();
      if (t.includes("masculin")) return "M";
      if (t.includes("féminin") || t.includes("feminin")) return "F";
    }
    return "";
  }

  /** Mandataire = société connectée affichée dans "Bienvenue, DREUX CARTE GRISE." */
  function readMandataire() {
    const m = document.body.innerText.match(/Bienvenue[,\s]+(.+?)\s*\./i);
    return m ? m[1].trim() : "";
  }

  function todayStr() {
    const d = new Date();
    return `${String(d.getDate()).padStart(2,"0")}/${String(d.getMonth()+1).padStart(2,"0")}/${d.getFullYear()}`;
  }

  // ─── Lecture ÉCRAN VÉHICULE (ivo_cht_recherche_init) ──────────────────────

  function readEcranVehicule() {
    const data = {
      screen:           "vehicule",
      dossier:          getDossier(),
      mandataire_nom:   readMandataire(),
      mandataire_siret: byLabel("SIREN/SIRET") || byLabel("SIRET") || byName("siret"),
      immatriculation:  (
        byLabel("Numéro d'immatriculation") || byName("numImmat", "immat", "immatriculation")
      ).toUpperCase().replace(/\s+/g, "-"),
      vin: (
        byLabel("Numéro d'identification véhicule") || byName("vin", "numVin", "numIdent")
      ).toUpperCase(),
      numero_formule: (
        byLabel("Numéro de formule du CI") || byLabel("Numéro de formule") || byName("formule", "numFormule")
      ),
    };

    console.log("[SIV→CERFA] Écran véhicule lu :", data);
    chrome.storage.local.set({ siv_vehicule: data });
    showToast("✅ Infos véhicule mémorisées");
    return data;
  }

  // ─── Lecture ÉCRAN TITULAIRE (sp_saisiepers) ──────────────────────────────

  function readEcranTitulaire() {
    // Select type de voie (ex: <select name="typeVoie">)
    const selTypeVoie = document.querySelector(
      'select[name*="typeVoie"], select[name*="type_voie"], select[name*="TypeVoie"]'
    );

    const data = {
      screen:   "titulaire",
      type:     "personne_physique",
      // Identité
      nom:               byLabel("(*) Nom")    || byLabel("Nom :")    || byName("nom"),
      nom_usage:         byLabel("Nom d'usage")                       || byName("nomUsage"),
      prenom:            byLabel("(*) Prénom") || byLabel("Prénom :") || byName("prenom"),
      sexe:              readSexe(),
      date_naissance:    byLabel("(*) Date de naissance") || byLabel("Date de naissance") || byName("dateNaissance"),
      commune_naissance: byLabel("(*) Commune")           || byLabel("Commune :")          || byName("communeNaissance"),
      departement_naissance: byLabel("(*) Département")  || byLabel("Département :")       || byName("departement"),
      // Adresse
      etage:        byLabel("Etage / Escalier"),
      immeuble:     byLabel("Immeuble / Résidence"),
      num_voie:     byLabel("Numéro")    || byName("numVoie", "numero"),
      type_voie:    selTypeVoie?.value?.trim() || byLabel("Type")   || byName("typeVoie"),
      libelle_voie: byLabel("Libellé")  || byName("libelleVoie", "libelle"),
      lieu_dit:     byLabel("Lieu-dit") || byName("lieuDit"),
      code_postal:  byLabel("Code postal")       || byName("codePostal", "cp"),
      commune:      byLabel("Bureau distributeur") || byLabel("Commune") || byName("bureauDistributeur", "commune"),
    };

    console.log("[SIV→CERFA] Écran titulaire lu :", data);
    chrome.storage.local.set({ siv_titulaire: data });
    showToast("✅ Infos titulaire mémorisées");
    return data;
  }

  // ─── Lecture ÉCRAN CO-TITULAIRE (sp_action) ───────────────────────────────
  // Cet écran affiche le tableau "Titulaire et Co-titulaires déclarés"
  // On y lit le nom validé du titulaire pour vérification

  function readEcranCotitulaire() {
    // Chercher "INES LEA OMONT" dans le tableau titulaire
    let nomRecapitule = "";
    const rows = document.querySelectorAll("table tr");
    for (const row of rows) {
      const cells = [...row.querySelectorAll("td")];
      // Ligne avec "(*) Titulaire" dans la 1re colonne
      if (cells[0]?.textContent?.includes("Titulaire")) {
        nomRecapitule = cells[1]?.textContent?.trim() || "";
        break;
      }
    }
    console.log("[SIV→CERFA] Écran co-titulaire — titulaire confirmé :", nomRecapitule);
    // Pas de sauvegarde supplémentaire nécessaire ici
    showToast(`✅ Titulaire confirmé : ${nomRecapitule || "—"}`);
  }

  // ─── Lecture ÉCRAN RÉCAPITULATIF (ivo_cht_toVal) ──────────────────────────

  async function buildPayload() {
    // 1. Véhicule depuis le récap (champs codes D.1, J.1, etc.)
    const vehicule = {
      vin:              readRecap("E")   || byLabel("Identification du Véhicule"),
      marque:           readRecap("D.1"),
      genre:            readRecap("J.1"),
      carrosserie:      readRecap("J.3"),
      puissance_fiscale: readRecap("P.6"),
      ptac:             readRecap("F.2"),
      energie:          readRecap("P.3"),
      taux_co2:         readRecap("V.7"),
    };

    // Date 1re immat (texte du récap)
    const dm = document.body.innerText.match(
      /Date de premi[eè]re immatriculation\s+(\d{2}\/\d{2}\/\d{4})/i
    );
    vehicule.date_premiere_immat = dm?.[1] || "";

    // 2. Titulaire depuis le tableau récap (Identité + Adresse)
    const titulaireRecap = parseTitulaireRecap();

    // 3. Fusionner avec données mémorisées (sp_saisiepers plus précis pour naissance/adresse)
    return new Promise((resolve) => {
      chrome.storage.local.get(["siv_vehicule", "siv_titulaire"], (stored) => {
        const sv = stored.siv_vehicule  || {};
        const st = stored.siv_titulaire || {};

        // Fusion : données écran dédié > parsing récap
        const titulaire = {
          type: "personne_physique",
          nom:                   st.nom                   || titulaireRecap.nom,
          prenom:                st.prenom                || titulaireRecap.prenom,
          nom_usage:             st.nom_usage             || titulaireRecap.nom_usage,
          sexe:                  st.sexe                  || titulaireRecap.sexe,
          date_naissance:        st.date_naissance        || titulaireRecap.date_naissance,
          commune_naissance:     st.commune_naissance     || titulaireRecap.commune_naissance,
          departement_naissance: st.departement_naissance || titulaireRecap.departement_naissance,
          etage:                 st.etage                 || titulaireRecap.etage,
          immeuble:              st.immeuble              || titulaireRecap.immeuble,
          num_voie:              st.num_voie              || titulaireRecap.num_voie,
          type_voie:             st.type_voie             || titulaireRecap.type_voie,
          libelle_voie:          st.libelle_voie          || titulaireRecap.libelle_voie,
          lieu_dit:              st.lieu_dit              || titulaireRecap.lieu_dit,
          code_postal:           st.code_postal           || titulaireRecap.code_postal,
          commune:               st.commune               || titulaireRecap.commune,
        };

        resolve({
          type_demarche:    "changement_proprietaire",
          dossier:          sv.dossier          || getDossier(),
          immatriculation:  sv.immatriculation  || "",
          numero_formule:   sv.numero_formule   || "",
          mandataire_nom:   sv.mandataire_nom   || readMandataire(),
          mandataire_siret: sv.mandataire_siret || "",
          vehicule,
          titulaire,
          fait_a:         "Dreux",
          date_signature: todayStr(),
        });
      });
    });
  }

  /**
   * Parse titulaire depuis le tableau du récapitulatif ivo_cht_toVal.
   * Colonnes : Identité | Adresse | Nature
   * Ex identité : "INES LEA OMONT\nné(e) le 21/01/2006 à LA TESTE DE BUCH (33)"
   * Ex adresse  : "5 RUE PASTEUR\n59300 VALENCIENNES"
   */
  function parseTitulaireRecap() {
    const r = {
      nom: "", prenom: "", nom_usage: "", sexe: "",
      date_naissance: "", commune_naissance: "", departement_naissance: "",
      num_voie: "", type_voie: "", libelle_voie: "",
      etage: "", immeuble: "", lieu_dit: "",
      code_postal: "", commune: "",
    };

    for (const row of document.querySelectorAll("table tr")) {
      const cells = [...row.querySelectorAll("td")];
      if (cells.length < 2) continue;
      const identity = cells[0]?.textContent?.trim() || "";
      const adresse  = cells[1]?.textContent?.trim() || "";
      if (!identity.match(/né\(e\)/i)) continue;

      // Nom / Prénom — 1re ligne, ordre "PRENOM(S) NOM" dans le SIV
      const nameLine = identity.split("\n")[0].trim();
      const parts    = nameLine.split(/\s+/);
      if (parts.length >= 2) {
        r.nom    = parts[parts.length - 1];
        r.prenom = parts.slice(0, -1).join(" ");
      } else {
        r.nom = nameLine;
      }

      // Naissance
      const nm = identity.match(
        /né\(e\)\s+le\s+(\d{2}\/\d{2}\/\d{4})\s+[àa]\s+(.+?)\s+\((\d{2,3})\)/i
      );
      if (nm) {
        r.date_naissance        = nm[1];
        r.commune_naissance     = nm[2].trim();
        r.departement_naissance = nm[3];
      }

      // Sexe depuis le bloc "Adresse d'expédition"
      const bodyTxt = document.body.innerText;
      if (/Adresse d.exp[eé]dition[\s\S]{0,40}MME/i.test(bodyTxt))   r.sexe = "F";
      else if (/Adresse d.exp[eé]dition[\s\S]{0,40}M\.\s/i.test(bodyTxt)) r.sexe = "M";

      // Adresse — "5 RUE PASTEUR\n59300 VALENCIENNES"
      const lines = adresse.split("\n").map(l => l.trim()).filter(Boolean);
      if (lines[0]) {
        const vm = lines[0].match(/^(\d+[a-zA-Z]?)\s+(bis|ter|quater)?\s*([A-ZÀÂÄÉÈÊËÎÏÔÙÛÜ]+)\.?\s+(.+)$/i);
        if (vm) {
          r.num_voie    = vm[1];
          r.type_voie   = vm[3];
          r.libelle_voie = vm[4].trim();
        } else {
          r.libelle_voie = lines[0];
        }
      }
      if (lines[1]) {
        const cm = lines[1].match(/^(\d{5})\s+(.+)$/);
        if (cm) { r.code_postal = cm[1]; r.commune = cm[2].trim(); }
      }
      break;
    }
    return r;
  }

  // ─── Toast ────────────────────────────────────────────────────────────────

  function showToast(msg, type = "success") {
    const ex = document.getElementById("siv-cerfa-toast");
    if (ex) ex.remove();
    const t = document.createElement("div");
    t.id = "siv-cerfa-toast";
    t.textContent = msg;
    const bg = { error:"#c0392b", info:"#2980b9", success:"#27ae60" }[type] || "#27ae60";
    t.style.cssText = `position:fixed;top:54px;right:16px;z-index:999999;
      background:${bg};color:#fff;padding:10px 18px;border-radius:6px;
      font:bold 13px/1.4 Arial,sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.3);
      cursor:pointer;max-width:400px;`;
    t.onclick = () => t.remove();
    document.body.appendChild(t);
    setTimeout(() => { t.style.opacity="0"; setTimeout(() => t.remove(), 400); }, 4500);
  }

  // ─── Barre d'outils ───────────────────────────────────────────────────────

  const SCREEN_LABELS = {
    vehicule:    "📋 Infos véhicule",
    titulaire:   "👤 Saisie titulaire",
    cotitulaire: "👥 Titulaire / Co-titulaire",
    recap:       "⭐ Récapitulatif",
    autre:       "—",
  };

  function injectToolbar() {
    if (document.getElementById("siv-cerfa-toolbar")) return;
    const dossier = getDossier();

    const isRecap = SCREEN === "recap";
    const bar = document.createElement("div");
    bar.id = "siv-cerfa-toolbar";
    bar.innerHTML = `
      <div class="siv-cerfa-logo">📄 SIV→CERFA</div>
      ${dossier ? `<div class="siv-cerfa-dossier">Dossier&nbsp;<strong>${dossier}</strong></div>` : ""}
      <div class="siv-cerfa-screen">${SCREEN_LABELS[SCREEN] || "—"}</div>
      <div class="siv-cerfa-spacer"></div>
      ${isRecap
        ? `<button id="siv-btn-generer" class="siv-btn siv-btn-primary">
             🖨️&nbsp;Générer les CERFA
           </button>`
        : `<button id="siv-btn-memo" class="siv-btn siv-btn-secondary">
             💾&nbsp;Mémoriser cet écran
           </button>`
      }
      <div id="siv-cerfa-status"></div>
    `;
    document.body.prepend(bar);

    document.getElementById("siv-btn-memo")?.addEventListener("click", () => {
      const btn = document.getElementById("siv-btn-memo");
      if (btn) { btn.disabled = true; btn.textContent = "⏳ Lecture..."; }

      setTimeout(() => {
        if      (SCREEN === "vehicule")    readEcranVehicule();
        else if (SCREEN === "titulaire")   readEcranTitulaire();
        else if (SCREEN === "cotitulaire") readEcranCotitulaire();
        else showToast("ℹ️ Pas de données à mémoriser sur cet écran", "info");

        if (btn) { btn.disabled = false; btn.textContent = "💾 Mémoriser cet écran"; }
      }, 200);
    });

    document.getElementById("siv-btn-generer")?.addEventListener("click", handleGenerer);
  }

  // ─── Générer les CERFA ────────────────────────────────────────────────────

  async function handleGenerer() {
    const btn    = document.getElementById("siv-btn-generer");
    const status = document.getElementById("siv-cerfa-status");
    if (btn) { btn.disabled = true; btn.textContent = "⏳ Lecture..."; }

    try {
      const payload = await buildPayload();
      console.log("[SIV→CERFA] Payload :", JSON.stringify(payload, null, 2));

      if (btn) btn.textContent = "⏳ Génération...";

      const resp = await fetch("http://localhost:5000/generer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!resp.ok) {
        const e = await resp.json().catch(() => ({}));
        throw new Error(e.error || `Erreur serveur ${resp.status}`);
      }

      const result = await resp.json();
      let count = 0;
      if (result.cerfa_13757_url) { window.open(result.cerfa_13757_url, "_blank"); count++; }
      if (result.cerfa_13750_url) { setTimeout(() => window.open(result.cerfa_13750_url, "_blank"), 400); count++; }

      showToast(`✅ ${count} CERFA générés — vérifiez les nouveaux onglets`);
      if (status) status.textContent = `✅ ${count} CERFA ouverts`;

    } catch (err) {
      const net = err.message?.includes("fetch") || err.message?.includes("Failed");
      showToast(
        net ? "❌ Service non démarré — double-cliquez sur start_server.bat" : `❌ ${err.message}`,
        "error"
      );
      if (status) status.textContent = net ? "❌ Service non démarré" : `❌ ${err.message}`;
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = "🖨️ Générer les CERFA"; }
    }
  }

  // ─── Init ─────────────────────────────────────────────────────────────────

  function init() {
    console.log(`[SIV→CERFA] action=${ACTION} → écran=${SCREEN}`);
    injectToolbar();
    // Lecture automatique silencieuse sur l'écran véhicule
    if (SCREEN === "vehicule") setTimeout(readEcranVehicule, 600);
    // Lecture automatique sur l'écran titulaire
    if (SCREEN === "titulaire") setTimeout(readEcranTitulaire, 600);
  }

  document.readyState === "loading"
    ? document.addEventListener("DOMContentLoaded", init)
    : init();

})();
