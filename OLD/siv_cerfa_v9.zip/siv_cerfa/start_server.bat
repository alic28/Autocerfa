@echo off
chcp 65001 >nul
title SIV CERFA - Serveur local v2.1

echo ==========================================
echo   SIV vers CERFA - Serveur local v2.1
echo   Dreux Carte Grise
echo ==========================================
echo.

cd /d "%~dp0"

echo [1/3] Verification de Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo ERREUR : Python n est pas installe ou absent du PATH.
    echo Telechargez Python sur https://python.org
    echo (Cocher "Add Python to PATH" lors de l installation)
    echo.
    pause
    exit /b 1
)
python --version

echo.
echo [2/3] Installation des dependances...
python -m pip install flask pypdf --quiet --disable-pip-version-check
if errorlevel 1 (
    echo ERREUR lors de l installation des dependances.
    pause
    exit /b 1
)
echo    Flask + pypdf OK

echo.
echo [3/3] Demarrage du serveur...
echo.
echo    URL : http://localhost:5000
echo    Laisser cette fenetre ouverte pendant l utilisation.
echo    Appuyer sur Ctrl+C pour arreter.
echo.
echo ==========================================
echo.

python server\server.py
if errorlevel 1 (
    echo.
    echo ERREUR au demarrage du serveur.
    echo Verifiez que le port 5000 n est pas deja utilise.
    pause
)
