"""
Mapping des champs pour le CERFA 13750*05 (Demande de Certificat d'Immatriculation).
Image template : 924 x 1316 px

Structure des bandes (lignes sombres mesurées) :
  y=47-48   : Ligne titre haut
  y=59-60   : Ligne titre bas
  y=166-183 : Bande VÉHICULE (header bleu)
  y=295     : Séparateur véhicule interne
  y=362     : Séparateur véhicule interne 2
  y=395/401 : Fin section véhicule / début TITULAIRE
  y=432-449 : Sous-bande Titulaire
  y=495     : Séparateur Titulaire adresse
  y=524     : Séparateur ligne voie
  y=602     : Fin section Titulaire / Co-titulaire
  y=693-710 : Bande LOUEUR
  y=747+    : Lignes LOCATAIRE
"""

CERFA_13750_FIELDS: list[dict] = [

    # ── Type de demande (checkboxes) — zone y=47-60 ────────────────────────
    {
        "key": "case_certificat",
        "x": 132, "y": 50,
        "max_width": 12, "font_size": 8,
        "description": "Case Certificat", "is_checkbox": True,
    },
    {
        "key": "case_duplicata",
        "x": 212, "y": 50,
        "max_width": 12, "font_size": 8,
        "description": "Case Duplicata", "is_checkbox": True,
    },
    {
        "key": "case_correction",
        "x": 311, "y": 50,
        "max_width": 12, "font_size": 8,
        "description": "Case Correction", "is_checkbox": True,
    },
    {
        "key": "case_changement_domicile",
        "x": 408, "y": 50,
        "max_width": 12, "font_size": 8,
        "description": "Case Changement de domicile", "is_checkbox": True,
    },

    # ── Section VÉHICULE — y=166-183 (bande), champs à y≈200-362 ──────────
    {
        "key": "vehicule_immatriculation",
        "x": 25, "y": 200,
        "max_width": 155, "font_size": 8,
        "description": "(A) N° immatriculation actuel",
    },
    {
        "key": "vehicule_date_achat",
        "x": 220, "y": 200,
        "max_width": 140, "font_size": 8,
        "description": "Date d'achat",
    },
    {
        "key": "vehicule_date_premiere_immat",
        "x": 695, "y": 200,
        "max_width": 220, "font_size": 8,
        "description": "(B) Date 1re immatriculation",
    },
    {
        "key": "vehicule_numero_formule",
        "x": 25, "y": 238,
        "max_width": 540, "font_size": 8,
        "description": "Numéro de formule",
    },
    {
        "key": "vehicule_marque",
        "x": 25, "y": 270,
        "max_width": 225, "font_size": 8,
        "description": "Marque (D.1)",
    },
    {
        "key": "vehicule_denomination",
        "x": 290, "y": 270,
        "max_width": 270, "font_size": 8,
        "description": "Dénomination commerciale (D.3)",
    },
    {
        "key": "vehicule_tvv",
        "x": 25, "y": 300,
        "max_width": 440, "font_size": 8,
        "description": "Type variante version (D.2)",
    },
    {
        "key": "vehicule_vin",
        "x": 25, "y": 332,
        "max_width": 280, "font_size": 8,
        "description": "Numéro identification véhicule (E)",
    },
    {
        "key": "vehicule_genre",
        "x": 350, "y": 332,
        "max_width": 200, "font_size": 8,
        "description": "Genre national (J.1)",
    },

    # ── Section TITULAIRE — y=432-449 (bande), champs à y≈455-602 ─────────
    # Personne physique / morale
    {
        "key": "titulaire_personne_physique",
        "x": 182, "y": 418,
        "max_width": 12, "font_size": 8,
        "description": "Case Personne physique", "is_checkbox": True,
    },
    {
        "key": "titulaire_sexe_m",
        "x": 262, "y": 418,
        "max_width": 12, "font_size": 8,
        "description": "Case Sexe M", "is_checkbox": True,
    },
    {
        "key": "titulaire_sexe_f",
        "x": 290, "y": 418,
        "max_width": 12, "font_size": 8,
        "description": "Case Sexe F", "is_checkbox": True,
    },
    {
        "key": "titulaire_personne_morale",
        "x": 383, "y": 418,
        "max_width": 12, "font_size": 8,
        "description": "Case Personne morale", "is_checkbox": True,
    },
    {
        "key": "titulaire_siren",
        "x": 528, "y": 418,
        "max_width": 180, "font_size": 8,
        "description": "N° SIREN",
    },

    # Nom/Prénom
    {
        "key": "titulaire_nom_prenom",
        "x": 25, "y": 455,
        "max_width": 500, "font_size": 9,
        "description": "NOM DE NAISSANCE / PRÉNOM / RAISON SOCIALE",
    },
    {
        "key": "titulaire_nom_usage",
        "x": 555, "y": 455,
        "max_width": 360, "font_size": 8,
        "description": "NOM D'USAGE",
    },

    # Naissance
    {
        "key": "titulaire_naissance_jour",
        "x": 25, "y": 482,
        "max_width": 38, "font_size": 8,
        "description": "Jour naissance",
    },
    {
        "key": "titulaire_naissance_mois",
        "x": 70, "y": 482,
        "max_width": 38, "font_size": 8,
        "description": "Mois naissance",
    },
    {
        "key": "titulaire_naissance_annee",
        "x": 115, "y": 482,
        "max_width": 50, "font_size": 8,
        "description": "Année naissance",
    },
    {
        "key": "titulaire_commune_naissance",
        "x": 198, "y": 482,
        "max_width": 270, "font_size": 8,
        "description": "Commune de naissance",
    },
    {
        "key": "titulaire_departement_naissance",
        "x": 502, "y": 482,
        "max_width": 120, "font_size": 8,
        "description": "Département naissance",
    },
    {
        "key": "titulaire_pays_naissance",
        "x": 640, "y": 482,
        "max_width": 275, "font_size": 8,
        "description": "Pays naissance",
    },

    # Domicile — Etage/Immeuble
    {
        "key": "titulaire_etage",
        "x": 25, "y": 508,
        "max_width": 215, "font_size": 8,
        "description": "Étage / Escalier / Appartement",
    },
    {
        "key": "titulaire_immeuble",
        "x": 440, "y": 508,
        "max_width": 475, "font_size": 8,
        "description": "Immeuble / Résidence / Bâtiment",
    },

    # Domicile — ligne voie
    {
        "key": "titulaire_num_voie",
        "x": 25, "y": 530,
        "max_width": 55, "font_size": 8,
        "description": "N° de la voie",
    },
    {
        "key": "titulaire_extension",
        "x": 90, "y": 530,
        "max_width": 58, "font_size": 8,
        "description": "Extension",
    },
    {
        "key": "titulaire_type_voie",
        "x": 158, "y": 530,
        "max_width": 130, "font_size": 8,
        "description": "Type de voie",
    },
    {
        "key": "titulaire_libelle_voie",
        "x": 300, "y": 530,
        "max_width": 614, "font_size": 8,
        "description": "Libellé de voie",
    },

    # Domicile — lieu-dit / téléphone
    {
        "key": "titulaire_lieu_dit",
        "x": 25, "y": 558,
        "max_width": 415, "font_size": 8,
        "description": "Lieu-dit / BP",
    },
    {
        "key": "titulaire_telephone",
        "x": 555, "y": 558,
        "max_width": 360, "font_size": 8,
        "description": "Téléphone",
    },

    # Domicile — CP / Commune / Email
    {
        "key": "titulaire_code_postal",
        "x": 25, "y": 583,
        "max_width": 75, "font_size": 8,
        "description": "Code postal",
    },
    {
        "key": "titulaire_commune",
        "x": 115, "y": 583,
        "max_width": 415, "font_size": 8,
        "description": "Commune",
    },
    {
        "key": "titulaire_email",
        "x": 555, "y": 583,
        "max_width": 360, "font_size": 8,
        "description": "Email",
    },

    # ── Signature ──────────────────────────────────────────────────────────
    {
        "key": "titulaire_fait_a",
        "x": 75, "y": 1148,
        "max_width": 150, "font_size": 8,
        "description": "Fait à",
    },
    {
        "key": "titulaire_date_signature",
        "x": 145, "y": 1162,
        "max_width": 115, "font_size": 8,
        "description": "Date signature",
    },
]
