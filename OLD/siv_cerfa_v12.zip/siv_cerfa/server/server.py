"""
SIV → CERFA — Service local Flask v3.2
Coordonnées calibrées par mesure visuelle sur grille pixel.
"""
import os, sys, json, tempfile
from datetime import datetime
from pathlib import Path

SERVER_DIR = Path(__file__).parent
sys.path.insert(0, str(SERVER_DIR))

from fill_pdf import fill_pdf_form
from flask import Flask, request, jsonify, send_file

BASE_DIR    = Path(__file__).parent.parent
TEMPLATES   = BASE_DIR / "templates"
OUTPUT_DIR  = BASE_DIR / "output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)

@app.after_request
def cors(r):
    r.headers["Access-Control-Allow-Origin"]  = "*"
    r.headers["Access-Control-Allow-Headers"] = "Content-Type"
    r.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return r

@app.route("/generer", methods=["OPTIONS"])
def gen_opt(): return "", 200

def field(desc, x0, y_line, x1, text, fs=9):
    """y_line = position EXACTE de la ligne du formulaire dans l'image (en pixels)."""
    return {
        "page_number": 1,
        "description": desc,
        "field_label": "l",
        "label_bounding_box": [x0-1, y_line-2, x0, y_line-1],
        "entry_bounding_box": [x0, y_line-15, x1, y_line],
        "entry_text": {"text": str(text), "font_size": fs}
    }

def build_fields_13757(d):
    t = d.get("titulaire", {})
    v = d.get("vehicule",  {})
    nom = f'{t.get("nom","").upper()} {t.get("prenom","").upper()}'.strip()
    j, m, a = _date_sig(d)
    return {
        "pages": [{"page_number": 1, "image_width": 1240, "image_height": 1755}],
        "form_fields": [
            field("Nom Prénom",  220, 348, 728, nom),
            field("N° voie",     180, 432, 240, t.get("num_voie",""),     8),
            field("Type voie",   360, 432, 460, t.get("type_voie",""),    8),
            field("Libellé",     475, 432, 730, t.get("libelle_voie",""), 8),
            field("CP",          120, 506, 195, t.get("code_postal",""),  8),
            field("Commune",     220, 506, 480, t.get("commune",""),       8),
            field("Marque",      225, 830, 638, v.get("marque","").upper()),
            field("VIN",         180, 910, 625, v.get("vin","").upper(),  8),
            field("Immat",       485,1014, 740, d.get("immatriculation","").upper()),
            field("Jour",        595,1218, 640, j, 8),
            field("Mois",        660,1218, 700, m, 8),
            field("Année",       725,1218, 780, a, 8),
        ]
    }

def build_fields_13750(d):
    """CERFA 13750 — y mesurés par auto-détection des traits du formulaire :
       289=immat A/B, 396=marque, 485=VIN/genre,
       664=nomPrénom, 703=naissance,
       776=adresse voie, 842=CP/commune.
       Spec = ligne + 6 pour texte juste au-dessus du trait."""
    t = d.get("titulaire", {})
    v = d.get("vehicule",  {})
    nom = f'{t.get("nom","").upper()} {t.get("prenom","").upper()}'.strip()
    nj, nm, na = _parse_date(t.get("date_naissance",""))
    return {
        "pages": [{"page_number": 1, "image_width": 1241, "image_height": 1754}],
        "form_fields": [
            field("Immat A",     50, 295, 280, d.get("immatriculation","").upper(), 8),
            field("Date B",     980, 295,1230, v.get("date_premiere_immat",""),     8),
            field("Marque",     115, 402, 480, v.get("marque","").upper(),           8),
            field("VIN",        115, 491, 420, v.get("vin","").upper(),              8),
            field("Genre",      575, 491, 720, v.get("genre","").upper(),            8),
            field("NomPrenom",  175, 670, 879, nom),
            field("Naiss J",     22, 709,  60, nj,                                  8),
            field("Naiss M",     67, 709, 110, nm,                                  8),
            field("Naiss A",    118, 709, 175, na,                                  8),
            field("Naiss Com",  240, 709, 650, t.get("commune_naissance","").upper(),8),
            field("Naiss Dep",  835, 709, 920, t.get("departement_naissance",""),   8),
            field("N° voie",    130, 782, 180, t.get("num_voie",""),                8),
            field("Type voie",  275, 782, 410, t.get("type_voie",""),               8),
            field("Libelle",    450, 782, 925, t.get("libelle_voie",""),            8),
            field("CP",          22, 848,  98, t.get("code_postal",""),             8),
            field("Commune",    170, 848, 685, t.get("commune",""),                 8),
        ]
    }

def _parse_date(s):
    if not s: return "", "", ""
    s = s.strip()
    for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            from datetime import datetime as dt
            d = dt.strptime(s, fmt)
            return f"{d.day:02d}", f"{d.month:02d}", str(d.year)
        except ValueError: pass
    return "", "", ""

def _date_sig(d):
    ds = d.get("date_signature","") or datetime.now().strftime("%d/%m/%Y")
    return _parse_date(ds)

def fill_cerfa(template_path, fields_data, output_path):
    tmp = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False, encoding='utf-8') as f:
            json.dump(fields_data, f, ensure_ascii=False)
            tmp = f.name
        fill_pdf_form(str(template_path), tmp, str(output_path))
        return output_path
    finally:
        if tmp and os.path.exists(tmp):
            os.unlink(tmp)

@app.route("/health")
def health(): return jsonify({"status": "ok", "version": "3.2"})

@app.route("/generer", methods=["POST"])
def generer():
    try:
        data = request.get_json(force=True) or {}
        print("\n" + "="*60)
        print("PAYLOAD RECU :")
        print(json.dumps(data, ensure_ascii=False, indent=2))
        print("="*60)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        immat = data.get("immatriculation","XX").replace("-","").upper()
        prefix = f"{ts}_{immat}_"
        result = {}
        out757 = OUTPUT_DIR / f"{prefix}cerfa_13757.pdf"
        fill_cerfa(TEMPLATES / "cerfa_13757_template.pdf", build_fields_13757(data), out757)
        result["cerfa_13757_url"] = f"http://localhost:5000/cerfa/{out757.name}"
        if data.get("type_demarche") == "changement_proprietaire":
            out750 = OUTPUT_DIR / f"{prefix}cerfa_13750.pdf"
            fill_cerfa(TEMPLATES / "cerfa_13750_template.pdf", build_fields_13750(data), out750)
            result["cerfa_13750_url"] = f"http://localhost:5000/cerfa/{out750.name}"
        return jsonify(result)
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({"error": str(e)}), 500

@app.route("/cerfa/<filename>")
def serve_cerfa(filename):
    if ".." in filename or "/" in filename or "\\" in filename: return "Interdit", 400
    p = OUTPUT_DIR / filename
    if not p.exists(): return "Introuvable", 404
    return send_file(str(p), mimetype="application/pdf", as_attachment=False)

@app.route("/list")
def list_cerfa():
    files = sorted(OUTPUT_DIR.glob("*.pdf"), key=lambda f: f.stat().st_mtime, reverse=True)
    return jsonify([{"name": f.name, "url": f"http://localhost:5000/cerfa/{f.name}"} for f in files[:20]])

if __name__ == "__main__":
    print("=" * 55)
    print("  SIV -> CERFA -- Serveur local v3.2")
    print(f"  URL      : http://localhost:5000")
    print(f"  Templates: {TEMPLATES}")
    print(f"  Output   : {OUTPUT_DIR}")
    print("=" * 55)
    app.run(host="127.0.0.1", port=5000, debug=False)
