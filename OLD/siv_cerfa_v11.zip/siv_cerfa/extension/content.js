/**
 * SIV → CERFA — content.js v3.0
 * Lecture directe des cellules de tableau sur l'écran ivo_cht_toVal.
 */
(function () {
  "use strict";

  const SERVER_URL = "http://localhost:5000/generer";

  function isRecapPage() {
    return window.location.href.includes("ivo_cht_toVal");
  }

  // ── Lecture des cellules ──────────────────────────────────────────────

  /** Retourne TOUTES les cellules (y compris courtes) */
  function getAllCells() {
    const cells = [];
    document.querySelectorAll("table td, table th").forEach(td => {
      const t = td.innerText.replace(/\s+/g, " ").trim();
      if (t.length > 0) cells.push(t);
    });
    return cells;
  }

  /** Valeur dans cells[] qui suit immédiatement le label exact */
  function cellAfter(cells, label) {
    const idx = cells.indexOf(label);
    return idx >= 0 && idx < cells.length - 1 ? cells[idx + 1].trim() : "";
  }

  /** Valeur dans cells[] qui suit le label contenant le texte */
  function cellAfterContains(cells, text) {
    const idx = cells.findIndex(c => c.includes(text));
    return idx >= 0 && idx < cells.length - 1 ? cells[idx + 1].trim() : "";
  }

  // ── Extraction ────────────────────────────────────────────────────────

  function extractData() {
    const cells   = getAllCells();
    const bodyTxt = document.body.innerText;

    // ── Dossier / immatriculation ─────────────────────────────────────
    const dossierCell = cells.find(c => /^[A-Z]{2}-\d{3}-[A-Z]{2}$/.test(c.trim()));
    const dossier = dossierCell || "";

    // ── Véhicule ──────────────────────────────────────────────────────
    // VIN : cellule après "Identification du Véhicule"
    const vin    = cellAfterContains(cells, "Identification du Véhicule");
    // Marque : cellule après "D.1"
    const marque = cellAfter(cells, "D.1");
    // Genre : cellule après "J.1" (peut être "VP", 2 chars)
    const j1Idx  = cells.indexOf("J.1");
    const genre  = j1Idx >= 0 ? cells[j1Idx + 1] || "" : "";
    // Date première immat : dans le texte brut
    const dateM  = bodyTxt.match(/premi.re\s+immatriculation\s+(\d{2}\/\d{2}\/\d{4})/i);
    const datePremImmat = dateM ? dateM[1] : "";

    // ── Titulaire ─────────────────────────────────────────────────────
    // La cellule "Identité" contient :
    // "INES LEA OMONT né(e) le 21/01/2006 à LA TESTE DE BUCH (33)"
    let nom = "", prenom = "", dateNaiss = "", communeNaiss = "", deptNaiss = "";
    const identCell = cells.find(c => /né\(?e?\)?\s+le\s+\d{2}\/\d{2}\/\d{4}/i.test(c));
    if (identCell) {
      // Parser nom+prénom et naissance
      const naissM = identCell.match(
        /^(.+?)\s+né\(?e?\)?\s+le\s+(\d{2}\/\d{2}\/\d{4})\s+à\s+(.+?)\s+\((\d{2,3})\)/i
      );
      if (naissM) {
        const fullName   = naissM[1].trim();
        dateNaiss        = naissM[2];
        communeNaiss     = naissM[3].trim();
        deptNaiss        = naissM[4];
        // Format SIV : "PRENOM NOM" → dernier mot = nom de famille
        const parts = fullName.split(" ");
        nom    = parts[parts.length - 1];
        prenom = parts.slice(0, -1).join(" ");
      }
    }

    // ── Adresse titulaire ─────────────────────────────────────────────
    // Cellule suivant la cellule identité :
    // "5 RUE PASTEUR 59300 VALENCIENNES"
    let numVoie = "", typeVoie = "", libelleVoie = "", cp = "", commune = "";
    const identIdx = cells.findIndex(c => /né\(?e?\)?\s+le\s+\d{2}\/\d{2}\/\d{4}/i.test(c));
    if (identIdx >= 0 && identIdx < cells.length - 1) {
      const adrCell = cells[identIdx + 1];
      // Doit contenir un code postal (5 chiffres)
      if (/\d{5}/.test(adrCell)) {
        const adrM = adrCell.match(
          /^(\d+)\s+(\S+)\s+([\s\S]+?)\s+(\d{5})\s+(.+)$/
        );
        if (adrM) {
          numVoie    = adrM[1];
          typeVoie   = adrM[2];
          libelleVoie = adrM[3].trim();
          cp         = adrM[4];
          commune    = adrM[5].trim();
        }
      }
    }

    return {
      type_demarche:   "changement_proprietaire",
      dossier:         dossier,
      immatriculation: dossier,
      mandataire_nom:  "DREUX CARTE GRISE",
      vehicule: {
        vin:                 vin,
        marque:              marque,
        genre:               genre,
        date_premiere_immat: datePremImmat,
      },
      titulaire: {
        nom:                    nom,
        prenom:                 prenom,
        date_naissance:         dateNaiss,
        commune_naissance:      communeNaiss,
        departement_naissance:  deptNaiss,
        num_voie:               numVoie,
        type_voie:              typeVoie,
        libelle_voie:           libelleVoie,
        code_postal:            cp,
        commune:                commune,
      },
      date_signature: today(),
    };
  }

  function today() {
    const d = new Date();
    return `${String(d.getDate()).padStart(2,"0")}/${String(d.getMonth()+1).padStart(2,"0")}/${d.getFullYear()}`;
  }

  // ── Barre orange ──────────────────────────────────────────────────────

  function injectBar() {
    if (document.getElementById("siv-cerfa-bar")) return;

    const bar = document.createElement("div");
    bar.id = "siv-cerfa-bar";
    Object.assign(bar.style, {
      position: "fixed", top: "0", left: "0", right: "0", zIndex: "99999",
      background: "#E55A00", color: "#fff",
      display: "flex", alignItems: "center",
      padding: "6px 14px", gap: "12px",
      font: "bold 14px Arial,sans-serif",
      boxShadow: "0 2px 6px rgba(0,0,0,.4)"
    });

    const title = document.createElement("span");
    title.textContent = "🖨 SIV→CERFA";

    const btn = document.createElement("button");
    btn.id = "siv-cerfa-btn";
    btn.textContent = "Générer les CERFA";
    Object.assign(btn.style, {
      background: "#fff", color: "#E55A00", border: "none",
      padding: "5px 16px", borderRadius: "4px",
      fontWeight: "bold", fontSize: "13px", cursor: "pointer"
    });

    const status = document.createElement("span");
    status.id = "siv-cerfa-status";
    status.style.fontSize = "12px";
    status.style.fontWeight = "normal";

    btn.onclick = handleGenerate;

    bar.appendChild(title);
    bar.appendChild(btn);
    bar.appendChild(status);
    document.body.prepend(bar);
    document.body.style.paddingTop = "38px";
  }

  async function handleGenerate() {
    const status = document.getElementById("siv-cerfa-status");
    const btn    = document.getElementById("siv-cerfa-btn");
    btn.disabled = true;
    status.style.color = "#fff";
    status.textContent = "⏳ Extraction des données…";

    try {
      const data = extractData();

      // Vérification minimale
      if (!data.dossier) throw new Error("Numéro de dossier introuvable");
      if (!data.titulaire.nom) throw new Error("Titulaire introuvable");

      status.textContent = "⏳ Génération PDF…";
      console.log("[SIV→CERFA] Payload :", JSON.stringify(data, null, 2));

      const resp = await fetch(SERVER_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });

      if (!resp.ok) throw new Error(`Serveur : HTTP ${resp.status}`);
      const result = await resp.json();
      if (result.error) throw new Error(result.error);

      const urls = Object.values(result).filter(u => typeof u === "string" && u.startsWith("http"));
      if (urls.length === 0) throw new Error("Aucun PDF généré");

      urls.forEach(u => window.open(u, "_blank"));

      status.style.color = "#AAFFAA";
      status.textContent = `✅ ${urls.length} CERFA ouvert(s) — ${data.titulaire.nom} ${data.titulaire.prenom}`;
    } catch (err) {
      status.style.color = "#FFAAAA";
      status.textContent = `❌ ${err.message}`;
      console.error("[SIV→CERFA]", err);
    } finally {
      btn.disabled = false;
    }
  }

  // Répondre aux messages du popup
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === "generer") handleGenerate();
  });

  // ── Init ──────────────────────────────────────────────────────────────

  function init() {
    if (!isRecapPage()) return;
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => setTimeout(injectBar, 600));
    } else {
      setTimeout(injectBar, 600);
    }
  }

  init();
})();
