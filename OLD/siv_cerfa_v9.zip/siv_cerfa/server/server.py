"""
SIV → CERFA — Service local Flask v2.1
Le script fill_pdf.py est inclus localement (ne nécessite plus /mnt/skills).
"""
import os, sys, json, tempfile
from datetime import datetime
from pathlib import Path

# Ajouter le dossier server/ au path pour importer fill_pdf
SERVER_DIR = Path(__file__).parent
sys.path.insert(0, str(SERVER_DIR))

from fill_pdf import fill_pdf_form          # importé localement
from flask import Flask, request, jsonify, send_file

BASE_DIR    = Path(__file__).parent.parent
TEMPLATES   = BASE_DIR / "templates"
OUTPUT_DIR  = BASE_DIR / "output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)

@app.after_request
def cors(r):
    r.headers["Access-Control-Allow-Origin"]  = "*"
    r.headers["Access-Control-Allow-Headers"] = "Content-Type"
    r.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return r

@app.route("/generer", methods=["OPTIONS"])
def gen_opt(): return "", 200

# ── Constructeurs de champs ───────────────────────────────────────────────

def field(desc, x0, y0, x1, y1, text, fs=9):
    """Crée un champ d'annotation pour le remplissage PDF."""
    return {
        "page_number": 1,
        "description": desc,
        "field_label": "l",
        "label_bounding_box": [x0-1, y0-2, x0, y0-1],
        "entry_bounding_box": [x0, y0, x1, y1],
        "entry_text": {"text": str(text), "font_size": fs}
    }

def build_fields_13757(d):
    """Champs du CERFA 13757 — Mandat (coordonnées calibrées sur grille 10px)."""
    t   = d.get("titulaire", {})
    v   = d.get("vehicule",  {})
    nom = f'{t.get("nom","").upper()} {t.get("prenom","").upper()}'.strip()
    j, m, a = _date_sig(d)

    return {
        "pages": [{"page_number": 1, "image_width": 1240, "image_height": 1755}],
        "form_fields": [
            field("Nom Prénom mandant", 174, 338, 728, 358, nom),
            field("N° voie",            214, 420, 270, 440, t.get("num_voie",""),      8),
            field("Type voie",          400, 420, 512, 440, t.get("type_voie",""),     8),
            field("Libellé voie",       518, 420, 728, 440, t.get("libelle_voie",""),  8),
            field("Code postal",         92, 490, 165, 510, t.get("code_postal",""),   8),
            field("Commune",            168, 490, 458, 510, t.get("commune",""),        8),
            field("Marque",             207, 812, 638, 832, v.get("marque","").upper()),
            field("VIN",                162, 898, 625, 918, v.get("vin","").upper(),    8),
            field("Immatriculation",    304,1002, 740,1022, d.get("immatriculation","").upper()),
            field("Jour",               578,1192, 632,1212, j, 8),
            field("Mois",               638,1192, 672,1212, m, 8),
            field("Année",              682,1192, 738,1212, a, 8),
        ]
    }

def build_fields_13750(d):
    """Champs du CERFA 13750 — Demande CI (coordonnées calibrées sur grille 10px)."""
    t   = d.get("titulaire", {})
    v   = d.get("vehicule",  {})
    nom = f'{t.get("nom","").upper()} {t.get("prenom","").upper()}'.strip()
    nj, nm, na = _parse_date(t.get("date_naissance",""))

    return {
        "pages": [{"page_number": 1, "image_width": 1241, "image_height": 1754}],
        "form_fields": [
            field("Immat A",      15, 240, 267, 260, d.get("immatriculation","").upper(), 8),
            field("Date B",      941, 240,1235, 260, v.get("date_premiere_immat",""),     8),
            field("Marque",       15, 378, 466, 398, v.get("marque","").upper(),           8),
            field("VIN",          15, 462, 420, 482, v.get("vin","").upper(),              8),
            field("Genre",       432, 462, 657, 482, v.get("genre","").upper(),            8),
            field("NomPrenom",   115, 650, 879, 670, nom),
            field("Naiss J",      18, 697,  62, 717, nj,                                  8),
            field("Naiss M",      65, 697, 110, 717, nm,                                  8),
            field("Naiss A",     116, 697, 175, 717, na,                                  8),
            field("Naiss Com",   222, 697, 652, 717, t.get("commune_naissance","").upper(),8),
            field("Naiss Dep",   833, 697, 930, 717, t.get("departement_naissance",""),   8),
            field("N° voie",     115, 752, 183, 772, t.get("num_voie",""),                8),
            field("Type voie",   254, 752, 424, 772, t.get("type_voie",""),               8),
            field("Libelle",     432, 752, 935, 772, t.get("libelle_voie",""),            8),
            field("CP",           18, 812, 100, 832, t.get("code_postal",""),             8),
            field("Commune",     115, 812, 690, 832, t.get("commune",""),                 8),
        ]
    }

# ── Utilitaires date ──────────────────────────────────────────────────────

def _parse_date(s):
    """Parse JJ/MM/AAAA ou AAAA-MM-JJ → (JJ, MM, AAAA)."""
    if not s: return "", "", ""
    s = s.strip()
    for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            from datetime import datetime as dt
            d = dt.strptime(s, fmt)
            return f"{d.day:02d}", f"{d.month:02d}", str(d.year)
        except ValueError:
            pass
    return "", "", ""

def _date_sig(d):
    ds = d.get("date_signature","") or datetime.now().strftime("%d/%m/%Y")
    return _parse_date(ds)

# ── Remplissage PDF ───────────────────────────────────────────────────────

def fill_cerfa(template_path, fields_data, output_path):
    """Remplit un PDF et le sauvegarde."""
    tmp = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json',
                                         delete=False, encoding='utf-8') as f:
            json.dump(fields_data, f, ensure_ascii=False)
            tmp = f.name
        fill_pdf_form(str(template_path), tmp, str(output_path))
        return output_path
    finally:
        if tmp and os.path.exists(tmp):
            os.unlink(tmp)

# ── Routes Flask ──────────────────────────────────────────────────────────

@app.route("/health")
def health():
    return jsonify({"status": "ok", "version": "2.1"})

@app.route("/generer", methods=["POST"])
def generer():
    try:
        data   = request.get_json(force=True) or {}
        ts     = datetime.now().strftime("%Y%m%d_%H%M%S")
        immat  = data.get("immatriculation","XX").replace("-","").upper()
        prefix = f"{ts}_{immat}_"
        result = {}

        print(f"[CERFA] Dossier={data.get('dossier','?')} "
              f"Démarche={data.get('type_demarche','?')}")

        # 13757 — toujours généré
        out757 = OUTPUT_DIR / f"{prefix}cerfa_13757.pdf"
        fill_cerfa(TEMPLATES / "cerfa_13757_template.pdf",
                   build_fields_13757(data), out757)
        result["cerfa_13757_url"] = f"http://localhost:5000/cerfa/{out757.name}"

        # 13750 — uniquement pour changement de propriétaire
        if data.get("type_demarche") == "changement_proprietaire":
            out750 = OUTPUT_DIR / f"{prefix}cerfa_13750.pdf"
            fill_cerfa(TEMPLATES / "cerfa_13750_template.pdf",
                       build_fields_13750(data), out750)
            result["cerfa_13750_url"] = f"http://localhost:5000/cerfa/{out750.name}"

        print(f"[CERFA] ✅ Générés : {list(result.keys())}")
        return jsonify(result)

    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({"error": str(e)}), 500

@app.route("/cerfa/<filename>")
def serve_cerfa(filename):
    if ".." in filename or "/" in filename or "\\" in filename:
        return "Interdit", 400
    p = OUTPUT_DIR / filename
    if not p.exists():
        return "Introuvable", 404
    return send_file(str(p), mimetype="application/pdf", as_attachment=False)

@app.route("/list")
def list_cerfa():
    files = sorted(OUTPUT_DIR.glob("*.pdf"),
                   key=lambda f: f.stat().st_mtime, reverse=True)
    return jsonify([
        {"name": f.name, "url": f"http://localhost:5000/cerfa/{f.name}"}
        for f in files[:20]
    ])

# ── Lancement ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 55)
    print("  SIV → CERFA — Serveur local v2.1")
    print(f"  URL      : http://localhost:5000")
    print(f"  Templates: {TEMPLATES}")
    print(f"  Output   : {OUTPUT_DIR}")
    print("=" * 55)
    app.run(host="127.0.0.1", port=5000, debug=False)
