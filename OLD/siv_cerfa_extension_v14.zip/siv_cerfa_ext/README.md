# SIV → CERFA — Extension Edge autonome

**Version 14.0** — 100% locale, aucun serveur, aucun .bat, aucune installation Python.

Génère automatiquement les CERFA 13750 et 13757 directement depuis l'écran récapitulatif du SIV Pro, dans le navigateur.

---

## Pour les salariés (utilisation au quotidien)

Une fois l'extension installée par le responsable :

1. Se connecter au [SIV Pro](https://pro-siv.interieur.gouv.fr) avec le certificat numérique habituel.
2. Saisir la démarche (changement de propriétaire ou cession) jusqu'à l'écran **Récapitulatif**.
3. Une **barre orange** apparaît automatiquement en haut de la page avec un bouton **« Générer les CERFA »**.
4. Cliquer dessus : 1 ou 2 nouveaux onglets s'ouvrent avec les CERFA pré-remplis, prêts à imprimer ou télécharger.

C'est tout. Aucune autre manipulation.

---

## Pour le responsable (installation par poste)

### Méthode rapide (5 minutes par poste)

1. Copier le dossier complet `siv_cerfa_extension` sur le poste (par ex. dans `C:\siv_cerfa_extension`).
2. Ouvrir Edge et coller dans la barre d'adresse : `edge://extensions/`
3. Activer **« Mode développeur »** (bouton en bas à gauche).
4. Cliquer sur **« Charger l'extension non empaquetée »**.
5. Sélectionner le dossier `siv_cerfa_extension`.
6. L'icône orange « CG » apparaît dans la barre Edge → c'est terminé.

### Méthode avancée (déploiement multi-postes via stratégie de groupe)

Pour une vraie distribution centralisée sans intervention sur chaque poste, voir `INSTALLATION.md` section « Déploiement par GPO ».

---

## Démarches supportées

| Démarche SIV                    | CERFA 13750 | CERFA 13757 |
|---------------------------------|:-----------:|:-----------:|
| Changement de titulaire         |     ✅      |     ✅      |
| Déclaration de cession          |     —       |     ✅      |

---

## Fichiers de personnalisation

Le dossier de l'extension contient trois fichiers que vous pouvez modifier sans tout reconstruire :

| Fichier | Rôle |
|---------|------|
| `coords.json` | Position pixel-précise de chaque champ sur les CERFA (déjà calibré) |
| `config.json` | Nom de la société mandataire, ville par défaut |
| `templates/cerfa_13757.jpg` | Image de fond du mandat (modifiable si template DCG personnalisé) |
| `templates/cerfa_13750.jpg` | Image de fond de la demande de certificat |

Après modification : `edge://extensions/` → bouton ↻ recharger sur l'extension.

---

## Aucun serveur ?

Tout fonctionne directement dans le navigateur :

- **pdf-lib** (513 KB, dans `lib/`) génère les PDFs côté client
- Les templates JPEG sont packagés dans l'extension
- Les coordonnées calibrées sont dans `coords.json`
- Aucune donnée ne quitte le navigateur (pas de serveur Flask, pas de localhost, pas d'appel réseau externe)

---

## Support

- Les logs détaillés sont visibles dans `F12 → Console` sur l'écran SIV.
- En cas de problème de rendu, vérifier que les templates et `coords.json` correspondent.

*Dreux Carte Grise — http://rapidcartegrise.fr*
