/**
 * SIV → CERFA — content.js v14.0
 *
 * Extension 100% locale : aucun serveur Python, aucune dépendance .bat.
 * Génère les CERFA directement dans le navigateur via pdf-lib.
 *
 * Workflow :
 *   - Sur l'écran récap (URL contient "ivo_cht_toVal") : injecte la barre orange + bouton
 *   - Au clic : extrait toutes les données du récap, génère 13750 + 13757 en local,
 *     ouvre les PDFs dans de nouveaux onglets prêts à imprimer.
 *
 * Type de démarche détecté :
 *   - "Changer le titulaire"      → CERFA 13750 + 13757
 *   - "Inscrire la cession"       → CERFA 13757 seul (mode mandat de cession)
 *   - autres                      → CERFA 13757 seul par défaut
 */

(function () {
  "use strict";

  const VERSION = "14.0.0";

  // ─── Détection écran récap ────────────────────────────────────────────

  function isRecapPage() {
    return window.location.href.includes("ivo_cht_toVal");
  }

  // ─── Helpers DOM ──────────────────────────────────────────────────────

  /** Toutes les cellules visibles du DOM, texte normalisé */
  function getAllCells() {
    const cells = [];
    document.querySelectorAll("table td, table th").forEach(td => {
      const t = td.innerText.replace(/\s+/g, " ").trim();
      if (t.length > 0) cells.push(t);
    });
    return cells;
  }

  /** Cellule qui suit immédiatement une cellule de texte exact */
  function cellAfter(cells, label) {
    const idx = cells.indexOf(label);
    return idx >= 0 && idx < cells.length - 1 ? cells[idx + 1].trim() : "";
  }

  /** Cellule qui suit une cellule contenant `text` (premier match) */
  function cellAfterContains(cells, text) {
    const idx = cells.findIndex(c => c.includes(text));
    return idx >= 0 && idx < cells.length - 1 ? cells[idx + 1].trim() : "";
  }

  // ─── Extraction écran récap ───────────────────────────────────────────

  function extractFromRecap() {
    const cells   = getAllCells();
    const bodyTxt = document.body.innerText;

    // ── Type de démarche (titre de page ou breadcrumb) ────────────────
    let demarche = "changement_proprietaire";
    if (/inscrire la cession|cession\s+v[ée]hicule/i.test(bodyTxt)) {
      demarche = "declaration_cession";
    } else if (/duplicata/i.test(bodyTxt)) {
      demarche = "duplicata";
    }

    // ── Dossier / immat (format AA-000-AA) ─────────────────────────────
    const immatRegex = /\b([A-Z]{2}-\d{3}-[A-Z]{2})\b/;
    const immatMatch = bodyTxt.match(immatRegex);
    const immat      = immatMatch ? immatMatch[1] : "";

    // ── VIN (17 caractères alphanumériques sans I/O/Q) ─────────────────
    const vinRegex = /\b([A-HJ-NPR-Z0-9]{17})\b/;
    const vinMatch = bodyTxt.match(vinRegex);
    const vin      = vinMatch ? vinMatch[1] : "";

    // ── Codes carte grise (D.1, J.1, etc.) ────────────────────────────
    const marque        = cellAfter(cells, "D.1") || cellAfterContains(cells, "Marque");
    const j1Idx         = cells.indexOf("J.1");
    const genre         = j1Idx >= 0 ? (cells[j1Idx + 1] || "") : "";
    const carrosserie   = cellAfter(cells, "J.3");
    const puissance     = cellAfter(cells, "P.6");
    const energie       = cellAfter(cells, "P.3");

    // ── Date première immat (texte brut) ──────────────────────────────
    const dateMatch = bodyTxt.match(/premi.re\s+immatriculation\s+(\d{2}\/\d{2}\/\d{4})/i);
    const datePremImmat = dateMatch ? dateMatch[1] : "";

    // ── Numéro de formule du CI ────────────────────────────────────────
    const formuleMatch = bodyTxt.match(/(?:N°\s*formule|num[ée]ro\s+de\s+formule)\D*([A-Z0-9]{8,})/i);
    const numFormule = formuleMatch ? formuleMatch[1] : "";

    // ── Identité titulaire ─────────────────────────────────────────────
    // Pattern type : "INES LEA OMONT né(e) le 21/01/2006 à LA TESTE DE BUCH (33)"
    const idMatch = bodyTxt.match(
      /([A-ZÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ][A-ZÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ\s\-']+)\s+n[ée]\(e\)\s+le\s+(\d{2}\/\d{2}\/\d{4})\s+[àa]\s+([A-ZÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ\s\-']+?)\s+\((\d{2,3}|\w{2,5})\)/i
    );

    let nom = "", prenom = "", dateNaiss = "", communeNaiss = "", deptNaiss = "";

    if (idMatch) {
      const fullName = idMatch[1].trim();
      dateNaiss      = idMatch[2];
      communeNaiss   = idMatch[3].trim();
      deptNaiss      = idMatch[4];
      // Convention : dernier mot = nom, le reste = prénoms
      const parts = fullName.split(/\s+/);
      if (parts.length >= 2) {
        nom    = parts[parts.length - 1];
        prenom = parts.slice(0, -1).join(" ");
      } else {
        nom = fullName;
      }
    }

    // ── Adresse titulaire ──────────────────────────────────────────────
    // Pattern type : "5 RUE PASTEUR 59300 VALENCIENNES"
    let numVoie = "", typeVoie = "", libelleVoie = "", codePostal = "", commune = "";

    const adrMatch = bodyTxt.match(
      /(\d+)\s+(RUE|AV|AVENUE|BD|BOULEVARD|ALLEE|ALLÉE|PLACE|CHEMIN|ROUTE|IMPASSE|SQUARE|QUAI|CHE|CHS|VOIE|RTE|PL|PASSAGE)\s+([A-ZÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ\s\-']+?)\s+(\d{5})\s+([A-ZÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ\s\-']+)/i
    );
    if (adrMatch) {
      numVoie     = adrMatch[1];
      typeVoie    = adrMatch[2];
      libelleVoie = adrMatch[3].trim();
      codePostal  = adrMatch[4];
      commune     = adrMatch[5].trim();
    }

    // ── Construction du payload ────────────────────────────────────────
    const today = new Date();
    const jj    = String(today.getDate()).padStart(2, "0");
    const mm    = String(today.getMonth() + 1).padStart(2, "0");
    const aaaa  = String(today.getFullYear());

    return {
      type_demarche: demarche,
      immat,
      vin,
      marque,
      genre_national: genre,
      carrosserie,
      puissance_fiscale: puissance,
      energie,
      date_premiere_immat: datePremImmat,
      numero_formule: numFormule,
      titulaire: {
        nom, prenom,
        date_naissance: dateNaiss,
        commune_naissance: communeNaiss,
        departement_naissance: deptNaiss,
        num_voie: numVoie,
        type_voie: typeVoie,
        libelle_voie: libelleVoie,
        code_postal: codePostal,
        commune
      },
      date_signature: { jj, mm, aaaa }
    };
  }

  // ─── Construction des champs CERFA depuis le payload ──────────────────

  function buildFields13757(payload, config) {
    const t = payload.titulaire || {};
    // Clés alignées sur coords.json (calibré) :
    // nom_prenom, num_voie, type_voie, libelle_voie, code_postal, commune,
    // marque, vin, immat, jour, mois, annee
    return {
      nom_prenom:    `${t.nom || ""} ${t.prenom || ""}`.trim().toUpperCase(),
      num_voie:      t.num_voie || "",
      type_voie:     (t.type_voie || "").toUpperCase(),
      libelle_voie:  (t.libelle_voie || "").toUpperCase(),
      code_postal:   t.code_postal || "",
      commune:       (t.commune || "").toUpperCase(),
      marque:        (payload.marque || "").toUpperCase(),
      vin:           (payload.vin || "").toUpperCase(),
      immat:         (payload.immat || "").toUpperCase(),
      jour:          payload.date_signature.jj,
      mois:          payload.date_signature.mm,
      annee:         payload.date_signature.aaaa
    };
  }

  function buildFields13750(payload) {
    const t = payload.titulaire || {};
    // Clés alignées sur coords.json (calibré) :
    // immat, date_immat, marque, vin, genre, nom_prenom,
    // naiss_jour, naiss_mois, naiss_annee, naiss_com, naiss_dep,
    // num_voie, type_voie, libelle_voie, code_postal, commune
    const [nj, nm, na] = (t.date_naissance || "").split("/");
    return {
      immat:        (payload.immat || "").toUpperCase(),
      date_immat:   payload.date_premiere_immat || "",
      marque:       (payload.marque || "").toUpperCase(),
      vin:          (payload.vin || "").toUpperCase(),
      genre:        (payload.genre_national || "").toUpperCase(),
      nom_prenom:   `${t.nom || ""} ${t.prenom || ""}`.trim().toUpperCase(),
      naiss_jour:   nj || "",
      naiss_mois:   nm || "",
      naiss_annee:  na || "",
      naiss_com:    (t.commune_naissance || "").toUpperCase(),
      naiss_dep:    t.departement_naissance || "",
      num_voie:     t.num_voie || "",
      type_voie:    (t.type_voie || "").toUpperCase(),
      libelle_voie: (t.libelle_voie || "").toUpperCase(),
      code_postal:  t.code_postal || "",
      commune:      (t.commune || "").toUpperCase()
    };
  }

  // ─── Recherche automatique du template ────────────────────────────────

  /**
   * Cherche le template parmi plusieurs extensions possibles.
   * Permet à l'utilisateur de mettre cerfa_13757.pdf, .jpg ou .png
   * sans avoir à modifier le code.
   */
  async function findTemplateUrl(formId) {
    const candidates = [
      `templates/cerfa_${formId}.pdf`,
      `templates/cerfa_${formId}.jpg`,
      `templates/cerfa_${formId}.jpeg`,
      `templates/cerfa_${formId}.png`
    ];
    for (const path of candidates) {
      const url = chrome.runtime.getURL(path);
      try {
        const r = await fetch(url, { method: "HEAD" });
        if (r.ok) return url;
      } catch (_) { /* essayer suivant */ }
    }
    throw new Error(
      `Aucun template trouvé pour le CERFA ${formId}. ` +
      `Placez cerfa_${formId}.pdf (ou .jpg / .png) dans le dossier templates/.`
    );
  }

  // ─── Génération PDFs et ouverture ─────────────────────────────────────

  async function generateAllCerfas() {
    // Charger les configs
    const [coords, config] = await Promise.all([
      fetch(chrome.runtime.getURL("coords.json")).then(r => r.json()),
      fetch(chrome.runtime.getURL("config.json")).then(r => r.json()).catch(() => ({}))
    ]);

    const payload = extractFromRecap();
    console.log("[SIV→CERFA] Payload extrait :", JSON.parse(JSON.stringify(payload)));

    const ts        = new Date().toISOString().slice(0, 19).replace(/[-:T]/g, "");
    const immatStr  = (payload.immat || "AAAAAAA").replace(/-/g, "");
    const baseName  = `${ts}_${immatStr}`;
    const generated = [];

    // CERFA 13757 (mandat) — toujours
    {
      const fields = buildFields13757(payload, config);
      const tplUrl = await findTemplateUrl("13757");
      const blob = await window.SivCerfaPdf.fillCerfa(
        "13757", fields, coords, tplUrl
      );
      generated.push({ name: `${baseName}_cerfa_13757.pdf`, blob });
    }

    // CERFA 13750 (demande certificat) — uniquement pour changement de proprio
    if (payload.type_demarche === "changement_proprietaire") {
      const fields = buildFields13750(payload);
      const tplUrl = await findTemplateUrl("13750");
      const blob = await window.SivCerfaPdf.fillCerfa(
        "13750", fields, coords, tplUrl
      );
      generated.push({ name: `${baseName}_cerfa_13750.pdf`, blob });
    }

    return { generated, payload };
  }

  // ─── Injection barre orange + bouton ──────────────────────────────────

  function injectBar() {
    if (document.getElementById("siv-cerfa-bar")) return;

    const bar = document.createElement("div");
    bar.id = "siv-cerfa-bar";

    const title = document.createElement("span");
    title.className = "siv-cerfa-title";
    title.textContent = "🖨 SIV → CERFA";

    const btn = document.createElement("button");
    btn.id = "siv-cerfa-btn";
    btn.type = "button";
    btn.textContent = "Générer les CERFA";

    const status = document.createElement("span");
    status.id = "siv-cerfa-status";

    btn.addEventListener("click", async () => {
      btn.disabled = true;
      status.textContent = "⏳ Génération en cours…";
      status.className = "";

      try {
        const { generated, payload } = await generateAllCerfas();

        if (generated.length === 0) {
          throw new Error("Aucun CERFA généré.");
        }

        // Ouvrir chaque PDF dans un nouvel onglet (ou télécharger selon config)
        for (const { name, blob } of generated) {
          const url = URL.createObjectURL(blob);

          // Ouvrir dans un onglet
          const win = window.open(url, "_blank");

          if (!win) {
            // Si bloqué (pop-up), fallback : déclencher download
            const a = document.createElement("a");
            a.href = url;
            a.download = name;
            document.body.appendChild(a);
            a.click();
            a.remove();
          }

          // Libérer le blob URL après 30s (le temps que le PDF soit chargé)
          setTimeout(() => URL.revokeObjectURL(url), 30_000);
        }

        const msg = `✅ ${generated.length} CERFA généré(s)`;
        status.textContent = msg;
        status.className = "siv-cerfa-ok";
        console.log("[SIV→CERFA]", msg, generated.map(g => g.name));
      } catch (err) {
        console.error("[SIV→CERFA] Erreur :", err);
        status.textContent = `❌ ${err.message}`;
        status.className = "siv-cerfa-ko";
      } finally {
        btn.disabled = false;
      }
    });

    bar.appendChild(title);
    bar.appendChild(btn);
    bar.appendChild(status);

    document.body.prepend(bar);
    document.body.classList.add("siv-cerfa-bar-active");
  }

  // ─── Init ─────────────────────────────────────────────────────────────

  function init() {
    console.log(`[SIV→CERFA] content.js v${VERSION} chargé sur ${location.href}`);
    if (!isRecapPage()) return;
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", injectBar);
    } else {
      // Léger délai pour laisser le DOM SIV finir de se rendre
      setTimeout(injectBar, 300);
    }
  }

  init();
})();
