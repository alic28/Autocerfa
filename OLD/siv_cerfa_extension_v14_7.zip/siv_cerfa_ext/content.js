/**
 * SIV → CERFA — content.js v14.0
 *
 * Extension 100% locale : aucun serveur Python, aucune dépendance .bat.
 * Génère les CERFA directement dans le navigateur via pdf-lib.
 *
 * Workflow :
 *   - Sur l'écran récap (URL contient "ivo_cht_toVal") : injecte la barre orange + bouton
 *   - Au clic : extrait toutes les données du récap, génère 13750 + 13757 en local,
 *     ouvre les PDFs dans de nouveaux onglets prêts à imprimer.
 *
 * Type de démarche détecté :
 *   - "Changer le titulaire"      → CERFA 13750 + 13757
 *   - "Inscrire la cession"       → CERFA 13757 seul (mode mandat de cession)
 *   - autres                      → CERFA 13757 seul par défaut
 */

(function () {
  "use strict";

  const VERSION = "14.7.0";

  // ─── Détection écran récap ────────────────────────────────────────────

  function isRecapPage() {
    return window.location.href.includes("ivo_cht_toVal");
  }

  // ─── Helpers DOM ──────────────────────────────────────────────────────

  /** Toutes les cellules visibles du DOM, texte normalisé */
  function getAllCells() {
    const cells = [];
    document.querySelectorAll("table td, table th").forEach(td => {
      const t = td.innerText.replace(/\s+/g, " ").trim();
      if (t.length > 0) cells.push(t);
    });
    return cells;
  }

  /** Cellule qui suit immédiatement une cellule de texte exact */
  function cellAfter(cells, label) {
    const idx = cells.indexOf(label);
    return idx >= 0 && idx < cells.length - 1 ? cells[idx + 1].trim() : "";
  }

  /** Cellule qui suit une cellule contenant `text` (premier match) */
  function cellAfterContains(cells, text) {
    const idx = cells.findIndex(c => c.includes(text));
    return idx >= 0 && idx < cells.length - 1 ? cells[idx + 1].trim() : "";
  }

  // ─── Extraction écran récap ───────────────────────────────────────────

  function extractFromRecap() {
    const cells   = getAllCells();
    // bodyTxt en lignes nettoyées (1 ligne = 1 bloc visuel) — bien plus précis que tout-en-un
    const lines   = document.body.innerText
      .split(/\r?\n/)
      .map(l => l.replace(/\s+/g, " ").trim())
      .filter(l => l.length > 0);
    const bodyTxt = lines.join("\n");

    // ── Type de démarche ─────────────────────────────────────────────
    // NOTE : pour l'instant on génère TOUJOURS 13750 + 13757 sur écran récap.
    //        La détection cession sera affinée quand on attaquera le workflow cession.
    const demarche = "changement_proprietaire";

    // ── Dossier / immat (format AA-000-AA) ─────────────────────────────
    const immatRegex = /\b([A-Z]{2}-\d{3}-[A-Z]{2})\b/;
    const immatMatch = bodyTxt.match(immatRegex);
    const immat      = immatMatch ? immatMatch[1] : "";

    // ── VIN (17 caractères alphanumériques sans I/O/Q) ─────────────────
    const vinRegex = /\b([A-HJ-NPR-Z0-9]{17})\b/;
    const vinMatch = bodyTxt.match(vinRegex);
    const vin      = vinMatch ? vinMatch[1] : "";

    // ── Codes carte grise (D.1, J.1, etc.) ────────────────────────────
    const marque        = cellAfter(cells, "D.1") || cellAfterContains(cells, "Marque");
    const j1Idx         = cells.indexOf("J.1");
    const genre         = j1Idx >= 0 ? (cells[j1Idx + 1] || "") : "";
    const carrosserie   = cellAfter(cells, "J.3");
    const puissance     = cellAfter(cells, "P.6");
    const energie       = cellAfter(cells, "P.3");

    // ── Date première immat ────────────────────────────────────────────
    const dateMatch = bodyTxt.match(/premi[èe]re\s+immatriculation[^0-9]{0,30}(\d{2}\/\d{2}\/\d{4})/i);
    const datePremImmat = dateMatch ? dateMatch[1] : "";

    // ── Numéro de formule du CI ────────────────────────────────────────
    const formuleMatch = bodyTxt.match(/(?:N°\s*formule|num[ée]ro\s+de\s+formule)[^A-Z0-9]{0,10}([A-Z0-9]{8,})/i);
    const numFormule = formuleMatch ? formuleMatch[1] : "";

    // ── Identité titulaire ─────────────────────────────────────────────
    // Sur certains écrans SIV le nom et le "né(e) le..." sont sur DEUX lignes séparées
    // (ex: tableau Titulaire avec deux <td> empilés). On matche donc ligne seule
    // OU ligne[i-1] + " " + ligne[i] pour reconstituer le pattern.
    let nom = "", prenom = "", dateNaiss = "", communeNaiss = "", deptNaiss = "";

    const idLineRegex = /\b([A-ZÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ][A-ZÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ\s\-']{1,60}?)\s+n[ée]\(e\)\s+le\s+(\d{2}\/\d{2}\/\d{4})\s+[àa]\s+([A-ZÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ\s\-']{1,40}?)\s+\(([0-9A-Z]{2,5})\)/i;

    function tryMatchId(text) {
      const m = text.match(idLineRegex);
      if (!m) return false;
      let fullName = m[1].trim().replace(/\s+/g, " ");
      // Couper sur mots-stop SIV au cas où le match aurait débordé
      fullName = fullName.split(/\s+(?:TITULAIRE|MENTIONS?|SANS|USAGE|VEHICULE|VÉHICULE|DOSSIER|CO\-?TITULAIRE|LOCATAIRE|LOUEUR|GENRE|NUMERO|NUMÉRO|IDENTIT[ÉE])\b/i)[0].trim();
      dateNaiss      = m[2];
      communeNaiss   = m[3].trim().replace(/\s+/g, " ");
      deptNaiss      = m[4];
      const parts = fullName.split(/\s+/);
      if (parts.length >= 2) {
        nom    = parts[parts.length - 1];
        prenom = parts.slice(0, -1).join(" ");
      } else {
        nom = fullName;
      }
      return true;
    }

    outerId:
    for (let i = 0; i < lines.length; i++) {
      // Essayer la ligne seule
      if (tryMatchId(lines[i])) break;
      // Sinon : ligne précédente + ligne courante (cas SIV avec nom sur ligne au-dessus)
      if (i > 0 && tryMatchId(lines[i-1] + " " + lines[i])) break outerId;
    }

    // ── Adresse titulaire ──────────────────────────────────────────────
    // Idem : "5 RUE PASTEUR" et "59300 VALENCIENNES" peuvent être sur deux lignes.
    let numVoie = "", typeVoie = "", libelleVoie = "", codePostal = "", commune = "";

    const adrLineRegex = /\b(\d+)\s+(RUE|AV|AVENUE|BD|BOULEVARD|ALL[ÉE]E|PLACE|CHEMIN|ROUTE|IMPASSE|SQUARE|QUAI|CHE|CHS|VOIE|RTE|PL|PASSAGE|COUR|COURS|RES|RESIDENCE|DOMAINE|LOTISSEMENT|LIEU.DIT|LIEU.|HAMEAU|FAUBOURG|VILLAGE|TRAVERSE|MONTEE|RAMPE|SENTIER|VENELLE|CARREFOUR|ESPLANADE|PARVIS|PROMENADE|ROND.POINT|RUELLE|PARC|PORT)\s+([A-ZÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ0-9\s\-']{1,50}?)\s+(\d{5})\s+([A-ZÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ\-']+(?:\s+[A-ZÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ\-']+){0,5})/i;

    function tryMatchAdr(text) {
      const m = text.match(adrLineRegex);
      if (!m) return false;
      numVoie     = m[1];
      typeVoie    = m[2];
      libelleVoie = m[3].trim().replace(/\s+/g, " ");
      codePostal  = m[4];
      commune     = m[5].trim().replace(/\s+/g, " ")
                      .split(/\s+(?:TITULAIRE|MENTIONS?|SANS|USAGE|VEHICULE|VÉHICULE|DOSSIER|CO\-?TITULAIRE|LOCATAIRE|LOUEUR|NATURE|ADRESSE|IDENTIT[ÉE])\b/i)[0]
                      .trim();
      return true;
    }

    outerAdr:
    for (let i = 0; i < lines.length; i++) {
      if (tryMatchAdr(lines[i])) break;
      // Cas SIV : la voie est sur ligne[i] et "CP COMMUNE" est sur ligne[i+1]
      if (i + 1 < lines.length && tryMatchAdr(lines[i] + " " + lines[i+1])) break outerAdr;
    }

    // ── Construction du payload ────────────────────────────────────────
    const today = new Date();
    const jj    = String(today.getDate()).padStart(2, "0");
    const mm    = String(today.getMonth() + 1).padStart(2, "0");
    const aaaa  = String(today.getFullYear());

    return {
      type_demarche: demarche,
      immat,
      vin,
      marque,
      genre_national: genre,
      carrosserie,
      puissance_fiscale: puissance,
      energie,
      date_premiere_immat: datePremImmat,
      numero_formule: numFormule,
      titulaire: {
        nom, prenom,
        date_naissance: dateNaiss,
        commune_naissance: communeNaiss,
        departement_naissance: deptNaiss,
        num_voie: numVoie,
        type_voie: typeVoie,
        libelle_voie: libelleVoie,
        code_postal: codePostal,
        commune
      },
      date_signature: { jj, mm, aaaa }
    };
  }

  // ─── Construction des champs CERFA depuis le payload ──────────────────

  function buildFields13757(payload, config) {
    const t = payload.titulaire || {};
    // Clés alignées sur coords.json (calibré) :
    // nom_prenom, num_voie, type_voie, libelle_voie, code_postal, commune,
    // marque, vin, immat, jour, mois, annee
    return {
      nom_prenom:    `${t.nom || ""} ${t.prenom || ""}`.trim().toUpperCase(),
      num_voie:      t.num_voie || "",
      type_voie:     (t.type_voie || "").toUpperCase(),
      libelle_voie:  (t.libelle_voie || "").toUpperCase(),
      code_postal:   t.code_postal || "",
      commune:       (t.commune || "").toUpperCase(),
      marque:        (payload.marque || "").toUpperCase(),
      vin:           (payload.vin || "").toUpperCase(),
      immat:         (payload.immat || "").toUpperCase(),
      jour:          payload.date_signature.jj,
      mois:          payload.date_signature.mm,
      annee:         payload.date_signature.aaaa
    };
  }

  function buildFields13750(payload) {
    const t = payload.titulaire || {};
    // Clés alignées sur coords.json (calibré) :
    // immat, date_immat, marque, vin, genre, nom_prenom,
    // naiss_jour, naiss_mois, naiss_annee, naiss_com, naiss_dep,
    // num_voie, type_voie, libelle_voie, code_postal, commune
    const [nj, nm, na] = (t.date_naissance || "").split("/");
    return {
      immat:        (payload.immat || "").toUpperCase(),
      date_immat:   payload.date_premiere_immat || "",
      marque:       (payload.marque || "").toUpperCase(),
      vin:          (payload.vin || "").toUpperCase(),
      genre:        (payload.genre_national || "").toUpperCase(),
      nom_prenom:   `${t.nom || ""} ${t.prenom || ""}`.trim().toUpperCase(),
      naiss_jour:   nj || "",
      naiss_mois:   nm || "",
      naiss_annee:  na || "",
      naiss_com:    (t.commune_naissance || "").toUpperCase(),
      naiss_dep:    t.departement_naissance || "",
      num_voie:     t.num_voie || "",
      type_voie:    (t.type_voie || "").toUpperCase(),
      libelle_voie: (t.libelle_voie || "").toUpperCase(),
      code_postal:  t.code_postal || "",
      commune:      (t.commune || "").toUpperCase()
    };
  }

  // ─── Recherche automatique du template ────────────────────────────────

  /**
   * Cherche le template parmi plusieurs extensions possibles.
   * Permet à l'utilisateur de mettre cerfa_13757.pdf, .jpg ou .png
   * sans avoir à modifier le code.
   */
  async function findTemplateUrl(formId) {
    const candidates = [
      `templates/cerfa_${formId}.pdf`,
      `templates/cerfa_${formId}.jpg`,
      `templates/cerfa_${formId}.jpeg`,
      `templates/cerfa_${formId}.png`
    ];
    for (const path of candidates) {
      const url = chrome.runtime.getURL(path);
      try {
        const r = await fetch(url, { method: "HEAD" });
        if (r.ok) return url;
      } catch (_) { /* essayer suivant */ }
    }
    throw new Error(
      `Aucun template trouvé pour le CERFA ${formId}. ` +
      `Placez cerfa_${formId}.pdf (ou .jpg / .png) dans le dossier templates/.`
    );
  }

  // ─── Génération PDFs et ouverture ─────────────────────────────────────

  async function generateAllCerfas() {
    // Charger les configs
    const [coords, config] = await Promise.all([
      fetch(chrome.runtime.getURL("coords.json")).then(r => r.json()),
      fetch(chrome.runtime.getURL("config.json")).then(r => r.json()).catch(() => ({}))
    ]);

    const payload = extractFromRecap();
    console.log("[SIV→CERFA] Payload extrait :", JSON.parse(JSON.stringify(payload)));
    if (config?.debug?.enabled) {
      console.log("[SIV→CERFA DEBUG] coords.json chargé :", coords);
      console.log("[SIV→CERFA DEBUG] Champs 13757 :", buildFields13757(payload, config));
      if (payload.type_demarche === "changement_proprietaire") {
        console.log("[SIV→CERFA DEBUG] Champs 13750 :", buildFields13750(payload));
      }
    }

    const ts        = new Date().toISOString().slice(0, 19).replace(/[-:T]/g, "");
    const immatStr  = (payload.immat || "AAAAAAA").replace(/-/g, "");
    const baseName  = `${ts}_${immatStr}`;
    const generated = [];

    // CERFA 13757 (mandat) — toujours
    {
      const fields = buildFields13757(payload, config);
      const tplUrl = await findTemplateUrl("13757");
      const blob = await window.SivCerfaPdf.fillCerfa(
        "13757", fields, coords, tplUrl,
        {
          debug: !!(config?.debug?.enabled),
          render: config?.render || {}
        }
      );
      generated.push({ name: `${baseName}_cerfa_13757.pdf`, blob });
    }

    // CERFA 13750 (demande certificat) — uniquement pour changement de proprio
    if (payload.type_demarche === "changement_proprietaire") {
      const fields = buildFields13750(payload);
      const tplUrl = await findTemplateUrl("13750");
      const blob = await window.SivCerfaPdf.fillCerfa(
        "13750", fields, coords, tplUrl,
        {
          debug: !!(config?.debug?.enabled),
          render: config?.render || {}
        }
      );
      generated.push({ name: `${baseName}_cerfa_13750.pdf`, blob });
    }

    return { generated, payload };
  }

  // ─── Injection barre orange + bouton ──────────────────────────────────

  function injectBar() {
    if (document.getElementById("siv-cerfa-bar")) return;

    const bar = document.createElement("div");
    bar.id = "siv-cerfa-bar";

    const title = document.createElement("span");
    title.className = "siv-cerfa-title";
    title.textContent = "🖨 SIV → CERFA";

    const btn = document.createElement("button");
    btn.id = "siv-cerfa-btn";
    btn.type = "button";
    btn.textContent = "Générer les CERFA";

    const status = document.createElement("span");
    status.id = "siv-cerfa-status";

    btn.addEventListener("click", async () => {
      btn.disabled = true;
      status.textContent = "⏳ Génération en cours…";
      status.className = "";

      try {
        const { generated, payload } = await generateAllCerfas();

        if (generated.length === 0) {
          throw new Error("Aucun CERFA généré.");
        }

        // Ouvrir chaque PDF dans un nouvel onglet (ou télécharger selon config)
        for (const { name, blob } of generated) {
          const url = URL.createObjectURL(blob);

          // Ouvrir dans un onglet
          const win = window.open(url, "_blank");

          if (!win) {
            // Si bloqué (pop-up), fallback : déclencher download
            const a = document.createElement("a");
            a.href = url;
            a.download = name;
            document.body.appendChild(a);
            a.click();
            a.remove();
          }

          // Libérer le blob URL après 30s (le temps que le PDF soit chargé)
          setTimeout(() => URL.revokeObjectURL(url), 30_000);
        }

        const msg = `✅ ${generated.length} CERFA généré(s)`;
        status.textContent = msg;
        status.className = "siv-cerfa-ok";
        console.log("[SIV→CERFA]", msg, generated.map(g => g.name));
      } catch (err) {
        console.error("[SIV→CERFA] Erreur :", err);
        status.textContent = `❌ ${err.message}`;
        status.className = "siv-cerfa-ko";
      } finally {
        btn.disabled = false;
      }
    });

    bar.appendChild(title);
    bar.appendChild(btn);
    bar.appendChild(status);

    document.body.prepend(bar);
    document.body.classList.add("siv-cerfa-bar-active");
  }

  // ─── Init ─────────────────────────────────────────────────────────────

  function init() {
    console.log(`[SIV→CERFA] content.js v${VERSION} chargé sur ${location.href}`);
    if (!isRecapPage()) return;
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", injectBar);
    } else {
      // Léger délai pour laisser le DOM SIV finir de se rendre
      setTimeout(injectBar, 300);
    }
  }

  init();
})();
