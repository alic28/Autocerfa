"""
Mapping des champs pour le CERFA 13757 (Mandat d'immatriculation).
Image template : 924 x 1316 px

Structure des bandes horizontales (lignes sombres) mesurées :
  y=220-221 : Top form box
  y=257     : Séparateur ligne 1 (Je soussigné / adresse voie)
  y=330     : Séparateur ligne 2 (adresse voie / CP-commune-pays)
  y=399     : Séparateur ligne 3 (mandant / mandataire)
  y=470     : Séparateur ligne 4 (mandataire / pour effectuer)
  y=577     : Dessus boîte Marque
  y=741     : Dessous boîte Marque / dessus VIN
  y=817+    : Cellules VIN
  y=971     : Zone immatriculation
  y=1167    : Début zone signature
"""

CERFA_13757_FIELDS: list[dict] = [

    # ── Mandant (Je soussigné) — row y=220-257, fill at y≈232 ─────────────
    {
        "key": "mandant_nom_prenom",
        "x": 170, "y": 228,
        "max_width": 440, "font_size": 9,
        "description": "NOM, PRÉNOM ou RAISON SOCIALE du mandant",
    },
    {
        "key": "mandant_siret",
        "x": 680, "y": 228,
        "max_width": 220, "font_size": 8,
        "description": "N° SIRET du mandant",
    },

    # ── Adresse mandant — row y=257-330, fill at y≈268 ────────────────────
    {
        "key": "mandant_num_voie",
        "x": 135, "y": 268,
        "max_width": 45, "font_size": 8,
        "description": "N° de la voie",
    },
    {
        "key": "mandant_extension",
        "x": 186, "y": 268,
        "max_width": 52, "font_size": 8,
        "description": "Extension (bis, ter...)",
    },
    {
        "key": "mandant_type_voie",
        "x": 245, "y": 268,
        "max_width": 93, "font_size": 8,
        "description": "Type de voie",
    },
    {
        "key": "mandant_nom_voie",
        "x": 344, "y": 268,
        "max_width": 568, "font_size": 8,
        "description": "Nom de la voie",
    },

    # ── Code postal / Commune / Pays — row y=330-399, fill at y≈342 ───────
    {
        "key": "mandant_code_postal",
        "x": 100, "y": 342,
        "max_width": 78, "font_size": 8,
        "description": "Code postal",
    },
    {
        "key": "mandant_commune",
        "x": 205, "y": 342,
        "max_width": 370, "font_size": 8,
        "description": "Nom de la commune",
    },
    {
        "key": "mandant_pays",
        "x": 603, "y": 342,
        "max_width": 309, "font_size": 8,
        "description": "Pays",
    },

    # ── Mandataire — row y=399-470, fill at y≈410 ─────────────────────────
    {
        "key": "mandataire_nom_raison",
        "x": 170, "y": 408,
        "max_width": 440, "font_size": 9,
        "description": "NOM/RAISON SOCIALE du mandataire",
    },
    {
        "key": "mandataire_siret",
        "x": 680, "y": 408,
        "max_width": 220, "font_size": 8,
        "description": "N° SIRET du mandataire",
    },

    # ── Opération d'immatriculation — fill at y≈550 ────────────────────────
    {
        "key": "operation_immatriculation",
        "x": 100, "y": 552,
        "max_width": 800, "font_size": 8,
        "description": "Description opération immatriculation",
    },

    # ── Véhicule : Marque — box y=577-741, fill at y≈635 ─────────────────
    {
        "key": "vehicule_marque",
        "x": 185, "y": 635,
        "max_width": 500, "font_size": 9,
        "description": "Marque du véhicule",
    },

    # ── Véhicule : VIN — box y=741-817, fill at y≈773 ────────────────────
    {
        "key": "vehicule_vin",
        "x": 200, "y": 773,
        "max_width": 440, "font_size": 9,
        "description": "Numéro VIN",
    },

    # ── Véhicule : Immatriculation — fill at y≈940 ────────────────────────
    {
        "key": "vehicule_immatriculation",
        "x": 373, "y": 940,
        "max_width": 310, "font_size": 9,
        "description": "Numéro d'immatriculation",
    },

    # ── Signature — y≈1167+, fill at y≈1150 ──────────────────────────────
    {
        "key": "fait_a",
        "x": 95, "y": 1148,
        "max_width": 430, "font_size": 9,
        "description": "Fait à (lieu)",
    },
    {
        "key": "date_jour",
        "x": 580, "y": 1148,
        "max_width": 45, "font_size": 9,
        "description": "Jour",
    },
    {
        "key": "date_mois",
        "x": 640, "y": 1148,
        "max_width": 45, "font_size": 9,
        "description": "Mois",
    },
    {
        "key": "date_annee",
        "x": 703, "y": 1148,
        "max_width": 70, "font_size": 9,
        "description": "Année",
    },
]
