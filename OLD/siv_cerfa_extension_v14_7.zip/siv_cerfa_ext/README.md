# SIV → CERFA — Extension Edge | Dreux Carte Grise

**Version 14.2** — production

Génère automatiquement les CERFA 13750 et 13757 directement depuis l'écran récapitulatif du SIV Pro. **100% local**, aucun serveur, aucun .bat, aucune installation Python.

Tous les templates DCG personnalisés et les coordonnées calibrées sont déjà intégrés dans cette version.

---

## Pour les salariés (utilisation au quotidien)

1. Se connecter au [SIV Pro](https://pro-siv.interieur.gouv.fr) avec le certificat numérique habituel.
2. Saisir la démarche jusqu'à l'écran **Récapitulatif**.
3. Une **barre orange** apparaît en haut de la page avec un bouton **« Générer les CERFA »**.
4. Cliquer dessus → 1 ou 2 onglets s'ouvrent avec les CERFA pré-remplis, prêts à imprimer.

C'est tout.

---

## Installation par poste (5 minutes, à faire une seule fois)

1. Décompresser `siv_cerfa_ext` à un emplacement stable :
   - **Recommandé** : `C:\Outils\siv_cerfa_ext` ou un partage réseau lisible
   - **À éviter** : un dossier temporaire ou avec espaces/accents
2. Ouvrir Edge → barre d'adresse : `edge://extensions/`
3. Activer **« Mode développeur »** (interrupteur bas-gauche)
4. Cliquer **« Charger l'extension non empaquetée »** → sélectionner le dossier `siv_cerfa_ext`
5. (Optionnel) Cliquer le puzzle 🧩 en haut à droite → épingler 📌 l'extension

---

## Démarches supportées

| Démarche SIV                    | CERFA 13750 | CERFA 13757 |
|---------------------------------|:-----------:|:-----------:|
| Changement de titulaire         |     ✅      |     ✅      |
| Déclaration de cession          |     —       |    🔜       |

> Le workflow déclaration de cession (mandat 13757 seul) sera ajouté dans une prochaine version. Le code détecte déjà le type de démarche via le titre de page.

---

## Contenu de l'extension

```
siv_cerfa_ext/
├── manifest.json                Déclaration de l'extension
├── content.js                   Lit les écrans SIV + injecte la barre orange
├── content.css                  Styles de la barre orange
├── pdf-generator.js             Générateur PDF (utilise pdf-lib)
├── coords.json                  Coordonnées calibrées DCG (déjà intégrées)
├── config.json                  Config mandataire DCG
├── popup.html                   Popup d'info de l'extension
├── lib/
│   └── pdf-lib.min.js           Bibliothèque pdf-lib (513 KB)
├── templates/
│   ├── cerfa_13757.pdf          Mandat DCG personnalisé (avec SIRET)
│   └── cerfa_13750.pdf          Demande certificat officielle
└── icons/                       Icônes 16/48/128
```

---

## Confidentialité

- Aucune donnée ne quitte le navigateur
- Aucun appel réseau externe pendant la génération
- L'extension n'a accès qu'aux pages `https://pro-siv.interieur.gouv.fr/*`

---

## Mise à jour de l'extension

1. Remplacer le dossier complet par la nouvelle version
2. `edge://extensions/` → bouton **↻ Actualiser** sur l'extension
3. Recharger l'onglet SIV en cours

---

## Dépannage

| Problème | Solution |
|----------|----------|
| Barre orange absente | Vérifier que l'URL contient `ivo_cht_toVal`. F5 sur la page. |
| Pop-up bloqué | Cliquer l'icône bloqueur dans la barre d'adresse → Toujours autoriser |
| Données manquantes | F12 → Console → regarder `[SIV→CERFA] Payload extrait` |
| Extension désactivée au redémarrage | Edge désactive parfois le mode dev. Voir `INSTALLATION.md` pour déploiement GPO. |

---

*Dreux Carte Grise — http://rapidcartegrise.fr — 09.83.31.79.65*
