/**
 * SIV → CERFA — pdf-generator.js v14.1
 *
 * Remplit un PDF CERFA dans le navigateur via pdf-lib (déjà chargé).
 * Détecte automatiquement le format du template (JPEG, PNG ou PDF)
 * et utilise la méthode adéquate.
 *
 * Convention coords.json :
 *   x, y       = coin haut-gauche du texte, en pixels image (réf 1240×1755)
 *   w          = largeur disponible
 *   fs         = font size en pt PDF
 *   image_w/h  = dimensions de référence du template
 *
 * Conversion image → PDF :
 *   sx = pdf_width / image_width
 *   sy = pdf_height / image_height
 *   pdf_x      = x * sx
 *   baseline_y = pdf_height - y * sy - fs * 0.85
 */

(function (global) {
  "use strict";

  const A4_WIDTH_PT  = 595.28;
  const A4_HEIGHT_PT = 841.89;

  /**
   * Détecte le format d'un fichier par ses magic bytes.
   * @param {ArrayBuffer} bytes
   * @returns {"jpeg" | "png" | "pdf" | "unknown"}
   */
  function detectFormat(bytes) {
    const view = new Uint8Array(bytes);
    if (view.length < 4) return "unknown";

    // JPEG : FF D8 FF
    if (view[0] === 0xFF && view[1] === 0xD8 && view[2] === 0xFF) {
      return "jpeg";
    }
    // PNG : 89 50 4E 47
    if (view[0] === 0x89 && view[1] === 0x50 && view[2] === 0x4E && view[3] === 0x47) {
      return "png";
    }
    // PDF : 25 50 44 46 ("%PDF")
    if (view[0] === 0x25 && view[1] === 0x50 && view[2] === 0x44 && view[3] === 0x46) {
      return "pdf";
    }
    return "unknown";
  }

  /**
   * Génère un PDF CERFA rempli.
   * @param {string} formId        - "13750" ou "13757"
   * @param {object} payload       - { key: value }
   * @param {object} coords        - coords.json complet
   * @param {string} templateUrl   - chrome.runtime.getURL(...) du template
   * @returns {Promise<Blob>}
   */
  async function fillCerfa(formId, payload, coords, templateUrl) {
    const { PDFDocument, StandardFonts, rgb } = global.PDFLib;

    const formCoords = coords[formId];
    if (!formCoords) throw new Error(`Form ${formId} introuvable dans coords.json`);

    // ── Charger le template ──────────────────────────────────────────────
    const tplBytes = await fetch(templateUrl).then(r => {
      if (!r.ok) throw new Error(`Template ${templateUrl} introuvable (${r.status})`);
      return r.arrayBuffer();
    });

    const fmt = detectFormat(tplBytes);

    let pdfDoc;
    let page;
    let pageWidth;
    let pageHeight;

    if (fmt === "pdf") {
      // ── Cas PDF : charger directement et écrire par-dessus ─────────────
      pdfDoc = await PDFDocument.load(tplBytes);
      const pages = pdfDoc.getPages();
      if (pages.length === 0) throw new Error("Le template PDF n'a aucune page");
      page = pages[0];
      const sz = page.getSize();
      pageWidth  = sz.width;
      pageHeight = sz.height;
    } else if (fmt === "jpeg" || fmt === "png") {
      // ── Cas image : créer un PDF A4 et dessiner l'image en fond ────────
      pdfDoc = await PDFDocument.create();
      page = pdfDoc.addPage([A4_WIDTH_PT, A4_HEIGHT_PT]);
      pageWidth  = A4_WIDTH_PT;
      pageHeight = A4_HEIGHT_PT;

      const img = (fmt === "jpeg")
        ? await pdfDoc.embedJpg(tplBytes)
        : await pdfDoc.embedPng(tplBytes);

      page.drawImage(img, {
        x: 0, y: 0,
        width:  pageWidth,
        height: pageHeight
      });
    } else {
      // ── Format non reconnu : erreur explicite ──────────────────────────
      const head = new Uint8Array(tplBytes).slice(0, 4);
      const hex  = Array.from(head).map(b => b.toString(16).padStart(2, "0")).join(" ");
      throw new Error(
        `Template "${templateUrl}" : format non reconnu (magic bytes: ${hex}). ` +
        `Formats acceptés : JPEG, PNG, PDF.`
      );
    }

    // ── Embedder la police ───────────────────────────────────────────────
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica);

    // ── Calculer les facteurs de mise à l'échelle ────────────────────────
    const sx = pageWidth  / formCoords.image_width;
    const sy = pageHeight / formCoords.image_height;

    // ── Dessiner chaque champ ────────────────────────────────────────────
    for (const f of formCoords.fields) {
      let value = payload[f.key];
      if (value === undefined || value === null) continue;
      value = String(value).trim();
      if (!value) continue;

      const fs   = f.fs || 9;
      const xPt  = f.x * sx;
      const yTop = pageHeight - f.y * sy;
      const yBl  = yTop - fs * 0.85;

      const maxWidth = (f.w || 999) * sx;
      let displayText = value;
      let textWidth   = font.widthOfTextAtSize(displayText, fs);
      let fsAuto      = fs;

      if (textWidth > maxWidth && displayText.length > 3) {
        while (textWidth > maxWidth && fsAuto > fs - 3 && fsAuto > 6) {
          fsAuto -= 0.5;
          textWidth = font.widthOfTextAtSize(displayText, fsAuto);
        }
        if (textWidth > maxWidth) {
          while (displayText.length > 1 && font.widthOfTextAtSize(displayText + "…", fsAuto) > maxWidth) {
            displayText = displayText.slice(0, -1);
          }
          displayText += "…";
        }
      }

      page.drawText(displayText, {
        x: xPt, y: yBl, size: fsAuto, font, color: rgb(0, 0, 0)
      });
    }

    // ── Export ──────────────────────────────────────────────────────────
    const pdfBytes = await pdfDoc.save();
    return new Blob([pdfBytes], { type: "application/pdf" });
  }

  global.SivCerfaPdf = { fillCerfa, detectFormat };

})(window);
